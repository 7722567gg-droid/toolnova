// ============================================
// ToolNova - Main JavaScript v2
// Theme, search, rendering, micro-interactions
// ============================================

// ============================================
// Theme Management
// ============================================
const THEME_KEY = "toolnova-theme";

function getPreferredTheme() {
  const stored = localStorage.getItem(THEME_KEY);
  if (stored) return stored;
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function setTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(THEME_KEY, theme);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) {
    meta.setAttribute("content", theme === "dark" ? "#08080d" : "#ffffff");
  }
}

function initTheme() {
  setTheme(getPreferredTheme());
  const themeToggle = document.getElementById("theme-toggle");
  if (themeToggle) {
    themeToggle.addEventListener("click", () => {
      const current = document.documentElement.getAttribute("data-theme");
      setTheme(current === "dark" ? "light" : "dark");
    });
  }
}

window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {
  if (!localStorage.getItem(THEME_KEY)) {
    setTheme(e.matches ? "dark" : "light");
  }
});

// ============================================
// Header scroll effect
// ============================================
function initHeaderScroll() {
  const header = document.querySelector(".header");
  if (!header) return;
  let lastY = 0;
  const onScroll = () => {
    const y = window.scrollY;
    if (y > 8) header.classList.add("scrolled");
    else header.classList.remove("scrolled");
    lastY = y;
  };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

// ============================================
// Category color helpers
// ============================================
const CATEGORY_COLORS = {
  "chat": "#3b82f6",
  "image-gen": "#f59e0b",
  "video-gen": "#ef4444",
  "voice": "#8b5cf6",
  "music": "#ec4899",
  "coding": "#10b981",
  "writing": "#6366f1",
  "design": "#f43f5e",
  "productivity": "#a855f7",
  "marketing": "#06b6d4",
  "education": "#14b8a6",
  "research": "#0ea5e9",
  "business": "#475569",
  "3d": "#d946ef",
  "avatar": "#f97316",
  "other": "#64748b",
};

function getCategoryColor(catId) {
  return CATEGORY_COLORS[catId] || "#6366f1";
}

// ============================================
// SVG Icon Library
// ============================================
const ICONS = {
  search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
  arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
  arrowLeft: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  starFill: '<svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  verified: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l2.4 2.4 3.4-.4.4 3.4 2.4 2.4-2.4 2.4-.4 3.4-3.4-.4-2.4 2.4-2.4-2.4-3.4.4-.4-3.4L2 9.8l2.4-2.4L4.8 4l3.4.4L12 2zm-1 13.5l5-5-1.4-1.4-3.6 3.6-1.6-1.6L8 12.5l3 3z"/></svg>',
  trending: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>',
  new: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>',
  top: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>',
  popular: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>',
  free: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4"/><path d="M4 6v12c0 1.1.9 2 2 2h14v-4"/><path d="M18 12a2 2 0 0 0-2 2c0 1.1.9 2 2 2h4v-4h-4z"/></svg>',
  updated: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>',
  external: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>',
  spark: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0l2.5 9.5L24 12l-9.5 2.5L12 24l-2.5-9.5L0 12l9.5-2.5L12 0z"/></svg>',
  video: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
  image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
  writing: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>',
  coding: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
  voice: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>',
  music: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>',
  marketing: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>',
  productivity: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>',
  education: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>',
  chat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
  design: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
  research: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>',
  business: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>',
  "3d": '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
  avatar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
  other: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 0l2.5 9.5L24 12l-9.5 2.5L12 24l-2.5-9.5L0 12l9.5-2.5L12 0z"/></svg>',
};

// ============================================
// Logo component (with fallback)
// ============================================
function renderLogo(tool, size = 52) {
  const color = getCategoryColor(tool.category);
  const initials = tool.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  // Inline onerror to hide img and show fallback
  const fallbackId = `fallback-${tool.id}-${Math.random().toString(36).slice(2, 8)}`;
  return `
    <div class="tool-logo" style="--tool-color: ${color}">
      <img src="${tool.logo}" alt="${tool.name} logo" loading="lazy" onerror="this.style.display='none'; document.getElementById('${fallbackId}').style.display='flex';" />
      <div id="${fallbackId}" class="tool-logo-fallback" style="display:none; background-color: ${color};">${initials}</div>
    </div>
  `;
}

// ============================================
// Star rating renderer
// ============================================
function renderStars(rating) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5;
  let stars = "";
  for (let i = 0; i < 5; i++) {
    if (i < full) {
      stars += ICONS.starFill;
    } else if (i === full && half) {
      stars += `<svg viewBox="0 0 24 24"><defs><linearGradient id="half-${rating}"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="rgba(0,0,0,0.15)"/></linearGradient></defs><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="url(#half-${rating})"/></svg>`;
    } else {
      stars += `<svg viewBox="0 0 24 24" style="opacity:0.25">${ICONS.starFill.replace('<svg viewBox="0 0 24 24">', '').replace('</svg>', '')}</svg>`;
    }
  }
  return stars;
}

// ============================================
// Tool Card Renderer
// ============================================
function renderToolCard(tool) {
  const color = getCategoryColor(tool.category);
  let badges = '';
  if (tool.isNew) badges += `<span class="tool-badge tool-badge-new">${ICONS.spark} New</span>`;
  if (tool.trending) badges += `<span class="tool-badge tool-badge-trending">${ICONS.trending} Trending</span>`;
  if (tool.popular) badges += `<span class="tool-badge tool-badge-popular">${ICONS.popular} Popular</span>`;
  if (tool.topRated) badges += `<span class="tool-badge tool-badge-top">${ICONS.top} Top Rated</span>`;
  if (tool.recentlyUpdated) badges += `<span class="tool-badge tool-badge-updated">${ICONS.updated} Updated</span>`;
  if (tool.free) badges += `<span class="tool-badge tool-badge-free">${ICONS.free} Free</span>`;

  // Verified badge for top 3 by reviews
  const isVerified = tool.reviews >= 10000;
  const verifiedBadge = isVerified ? `<span class="tool-verified" title="Verified tool">${ICONS.verified}</span>` : '';

  return `
    <a href="./tool.html?id=${tool.id}" class="tool-card reveal" style="--tool-color: ${color}">
      <div class="tool-card-head">
        ${renderLogo(tool)}
        <div class="tool-name-block">
          <div class="tool-name">
            <span class="tool-name-text">${tool.name}</span>${verifiedBadge}
          </div>
          <div class="tool-cat">
            <span>${tool.category}</span>
            <span class="tool-cat-pricing">${tool.pricing === 'free' ? 'Free' : tool.pricing === 'freemium' ? 'Freemium' : 'Paid'}</span>
          </div>
          ${badges ? `<div class="tool-badges">${badges}</div>` : ''}
        </div>
      </div>
      <p class="tool-tagline">${tool.tagline}</p>
      <div class="tool-foot">
        <div class="tool-rating">
          <div class="tool-rating-stars">${renderStars(tool.rating)}</div>
          <span class="tool-rating-value">${tool.rating.toFixed(1)}</span>
          <span class="tool-rating-count">(${formatNumber(tool.reviews)})</span>
        </div>
        <span class="tool-visit">
          View
          ${ICONS.arrow}
        </span>
      </div>
    </a>
  `;
}

// ============================================
// Featured Tool Renderer
// ============================================
function renderFeaturedTool(tool) {
  const color = getCategoryColor(tool.category);
  const initials = tool.name.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const fallbackId = `feat-${tool.id}`;
  return `
    <div class="featured-card reveal">
      <div class="featured-visual" style="background: linear-gradient(135deg, ${color}, ${getCategoryColor(tool.category === 'image' ? 'coding' : 'image')});">
        <div class="featured-visual-content">
          <div class="featured-tag">${ICONS.spark} Tool of the Day</div>
          <div class="featured-visual-logo">
            <img src="${tool.logo}" alt="${tool.name}" onerror="this.style.display='none'; document.getElementById('${fallbackId}').style.display='flex';" />
            <div id="${fallbackId}" class="featured-visual-logo-fallback" style="display:none;">${initials}</div>
          </div>
          <div class="featured-visual-name">${tool.name}</div>
        </div>
      </div>
      <div class="featured-content">
        <span class="featured-eyebrow">${ICONS.spark} Editor's Pick</span>
        <h2 class="featured-title">${tool.name} — ${tool.tagline}</h2>
        <p class="featured-description">${tool.description}</p>
        <div class="featured-meta">
          <div class="featured-meta-item">
            <span class="featured-meta-label">Rating</span>
            <span class="featured-meta-value">⭐ ${tool.rating.toFixed(1)}</span>
          </div>
          <div class="featured-meta-item">
            <span class="featured-meta-label">Reviews</span>
            <span class="featured-meta-value">${formatNumber(tool.reviews)}</span>
          </div>
          <div class="featured-meta-item">
            <span class="featured-meta-label">Pricing</span>
            <span class="featured-meta-value">${tool.pricing === 'free' ? 'Free' : tool.pricing === 'freemium' ? 'Freemium' : 'Paid'}</span>
          </div>
          <div class="featured-meta-item">
            <span class="featured-meta-label">Category</span>
            <span class="featured-meta-value" style="text-transform: capitalize;">${tool.category}</span>
          </div>
        </div>
        <a href="./tool.html?id=${tool.id}" class="featured-cta">
          Explore ${tool.name}
          ${ICONS.arrow}
        </a>
      </div>
    </div>
  `;
}

// ============================================
// Category Card Renderer
// ============================================
function renderCategoryCard(cat) {
  const color = getCategoryColor(cat.id);
  return `
    <a href="./category.html?cat=${cat.id}" class="category-card reveal" style="--cat-color: ${color}; --cat-bg: ${color}1a">
      <div class="category-icon">
        ${ICONS[cat.icon] || ICONS.other}
      </div>
      <div class="category-name">${cat.name}</div>
      <div class="category-count">${cat.count} tool${cat.count !== 1 ? 's' : ''}</div>
    </a>
  `;
}

// ============================================
// Ticker / Logo Marquee
// ============================================
function renderTicker() {
  // Use top 12 most popular tools
  const top = [...TOOLS]
    .filter(t => t.reviews >= 1000)
    .sort((a, b) => b.reviews - a.reviews)
    .slice(0, 12);

  // Duplicate for seamless loop
  const items = [...top, ...top].map(t => `
    <span class="ticker-item">
      ${t.name}
    </span>
  `).join('');

  return `
    <div class="ticker-wrap">
      <div class="ticker-track">${items}</div>
    </div>
  `;
}

// ============================================
// Reveal on scroll
// ============================================
function initRevealOnScroll() {
  if (!("IntersectionObserver" in window)) {
    document.querySelectorAll(".reveal").forEach(el => el.classList.add("visible"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.05, rootMargin: "0px 0px -50px 0px" });

  document.querySelectorAll(".reveal:not(.visible)").forEach(el => observer.observe(el));
}

// ============================================
// Card mouse tracking (for the gradient follow effect)
// ============================================
function initCardMouseEffect() {
  document.querySelectorAll(".tool-card").forEach(card => {
    card.addEventListener("mousemove", (e) => {
      const rect = card.getBoundingClientRect();
      card.style.setProperty("--mouse-x", `${e.clientX - rect.left}px`);
      card.style.setProperty("--mouse-y", `${e.clientY - rect.top}px`);
    });
  });
}

// ============================================
// Animated counter
// ============================================
function animateCounter(el, target, duration = 1500, suffix = "") {
  const start = 0;
  const startTime = performance.now();
  const isNumber = typeof target === "number";

  function update(now) {
    const elapsed = now - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // ease-out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = start + (target - start) * eased;
    if (isNumber) {
      el.textContent = Math.floor(value) + suffix;
    } else {
      el.textContent = value + suffix;
    }
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

function initStatCounters() {
  const stats = [
    { id: "stat-tools", value: STATS.totalTools, suffix: "+" },
    { id: "stat-categories", value: STATS.totalCategories, suffix: "" },
    { id: "stat-free", value: STATS.freeTools, suffix: "+" },
    { id: "stat-new", value: STATS.newTools, suffix: "" },
  ];

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.id;
        const stat = stats.find(s => s.id === id);
        if (stat) {
          animateCounter(entry.target, stat.value, 1200, stat.suffix);
        }
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  stats.forEach(s => {
    const el = document.getElementById(s.id);
    if (el) observer.observe(el);
  });
}

// ============================================
// Search
// ============================================
function initSearch() {
  const searchInput = document.getElementById("search-input");
  const searchForm = document.getElementById("search-form");
  const searchBtn = document.getElementById("search-btn");
  if (!searchInput) return;

  function handleSearch(e) {
    if (e) e.preventDefault();
    const query = searchInput.value.trim();
    if (query) {
      window.location.href = `./search.html?q=${encodeURIComponent(query)}`;
    } else {
      window.location.href = `./tools.html`;
    }
  }

  if (searchForm) searchForm.addEventListener("submit", handleSearch);
  if (searchBtn) searchBtn.addEventListener("click", handleSearch);

  document.querySelectorAll(".suggestion-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      searchInput.value = chip.dataset.query || chip.textContent.trim();
      handleSearch();
    });
  });
}

// ============================================
// Mobile menu
// ============================================
function initMobileMenu() {
  const btn = document.getElementById("mobile-menu-btn");
  const nav = document.querySelector(".nav");
  if (!btn || !nav) return;

  btn.addEventListener("click", () => {
    nav.classList.toggle("open");
  });

  document.addEventListener("click", (e) => {
    if (!nav.contains(e.target) && !btn.contains(e.target)) {
      nav.classList.remove("open");
    }
  });
}

// ============================================
// Newsletter form
// ============================================
function initNewsletter() {
  const form = document.getElementById("newsletter-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const input = form.querySelector("input");
    if (input && input.value.trim()) {
      const btn = form.querySelector("button");
      if (btn) {
        btn.textContent = "Subscribed ✓";
        btn.disabled = true;
        setTimeout(() => {
          btn.textContent = "Subscribe";
          btn.disabled = false;
          input.value = "";
        }, 3000);
      }
    }
  });
}

// ============================================
// URL params
// ============================================
function getParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

// ============================================
// Format number
// ============================================
function formatNumber(n) {
  if (n >= 1e6) return (n / 1e6).toFixed(1) + 'M';
  if (n >= 1e3) return (n / 1e3).toFixed(1) + 'k';
  return n.toString();
}

// ============================================
// Format date relative
// ============================================
function formatDate(dateStr) {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const now = new Date();
  const diff = (now - d) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return Math.floor(diff / 60) + 'm ago';
  if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
  if (diff < 604800) return Math.floor(diff / 86400) + 'd ago';
  if (diff < 2592000) return Math.floor(diff / 604800) + 'w ago';
  if (diff < 31536000) return Math.floor(diff / 2592000) + 'mo ago';
  return Math.floor(diff / 31536000) + 'y ago';
}

// ============================================
// Site URL helper (for custom domain support)
// ============================================
function siteUrl(path) {
  const base = (window.SITE_CONFIG && window.SITE_CONFIG.url) || 'https://toolnova.com';
  if (!path) return base;
  if (path.startsWith('http')) return path;
  return base + (path.startsWith('/') ? path : '/' + path);
}

// ============================================
// Get featured tool of the day (deterministic by day)
// ============================================
function getFeaturedToolOfTheDay() {
  const featured = getFeaturedTools(8);
  if (featured.length === 0) return null;
  const day = Math.floor(Date.now() / 86400000);
  return featured[day % featured.length];
}

// ============================================
// Init
// ============================================
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initSearch();
  initMobileMenu();
  initHeaderScroll();
  initNewsletter();
  initStatCounters();
  initRevealOnScroll();
  // Init card mouse effect after a short delay (cards rendered after DOM)
  setTimeout(() => {
    initCardMouseEffect();
    initRevealOnScroll();
  }, 100);
});
