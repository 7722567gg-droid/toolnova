// ToolNova - AI Tools Database
// Global directory with 16 categories and bilingual (EN/AR) search

// ============================================
// 16 Categories with Arabic names
// ============================================
const CATEGORIES = [
  { id: "chat",         name: "AI Chat",                nameAr: "شات ذكاء اصطناعي",      icon: "chat",         color: "#3b82f6", count: 0 },
  { id: "image-gen",    name: "AI Image Generation",    nameAr: "مولد صور بالذكاء الاصطناعي", icon: "image",        color: "#f59e0b", count: 0 },
  { id: "video-gen",    name: "AI Video Generation",    nameAr: "توليد فيديو",          icon: "video",        color: "#ef4444", count: 0 },
  { id: "voice",        name: "AI Voice",               nameAr: "تعليق صوتي",          icon: "voice",        color: "#8b5cf6", count: 0 },
  { id: "music",        name: "AI Music",               nameAr: "تأليف موسيقي",         icon: "music",        color: "#ec4899", count: 0 },
  { id: "coding",       name: "AI Coding",              nameAr: "برمجة",                icon: "coding",       color: "#10b981", count: 0 },
  { id: "writing",      name: "AI Writing",             nameAr: "كتابة",                icon: "writing",      color: "#6366f1", count: 0 },
  { id: "design",       name: "AI Design",              nameAr: "تصميم",                icon: "design",       color: "#f43f5e", count: 0 },
  { id: "productivity", name: "AI Productivity",        nameAr: "إنتاجية",              icon: "productivity", color: "#a855f7", count: 0 },
  { id: "marketing",    name: "AI Marketing",           nameAr: "تسويق",                icon: "marketing",    color: "#06b6d4", count: 0 },
  { id: "education",    name: "AI Education",           nameAr: "تعليم",                icon: "education",    color: "#14b8a6", count: 0 },
  { id: "research",     name: "AI Research",            nameAr: "بحث",                  icon: "research",     color: "#0ea5e9", count: 0 },
  { id: "business",     name: "AI Business",            nameAr: "أعمال",                icon: "business",     color: "#475569", count: 0 },
  { id: "3d",           name: "AI 3D",                  nameAr: "ثلاثي الأبعاد",         icon: "3d",           color: "#d946ef", count: 0 },
  { id: "avatar",       name: "AI Avatar",              nameAr: "صور رمزية",            icon: "avatar",       color: "#f97316", count: 0 },
  { id: "other",        name: "Other",                  nameAr: "أخرى",                 icon: "other",        color: "#64748b", count: 0 },
];

// ============================================
// SEMANTIC SEARCH INFRASTRUCTURE
// Bilingual (English + Arabic) synonym expansion
// ============================================

// Category ID <-> readable concept mapping
const CATEGORY_CONCEPTS = {
  "chat":         ["chat", "assistant", "chatbot", "conversation", "talk", "Q&A", "gpt"],
  "image-gen":    ["image generation", "image generator", "picture", "photo", "art", "drawing", "illustration", "graphic", "painting", "sketch", "text to image", "t2i", "ai art"],
  "video-gen":    ["video generation", "video", "movie", "clip", "film", "animation", "text to video", "t2v"],
  "voice":        ["voice", "audio", "speech", "sound", "tts", "text to speech", "voiceover", "narration", "voice clone", "voice cloning", "dubbing"],
  "music":        ["music", "song", "melody", "tune", "track", "beat", "composition", "songwriter", "ai music", "music generator"],
  "coding":       ["code", "coding", "programming", "developer", "software", "script", "IDE", "code completion", "pair programming", "AI coding"],
  "writing":      ["writing", "write", "writer", "content", "article", "blog", "copy", "copywriting", "grammar", "editor", "editing", "text"],
  "design":       ["design", "graphic", "visual", "ui", "ux", "logo", "branding", "vector", "mockup", "layout"],
  "productivity": ["productivity", "organize", "task", "note", "schedule", "calendar", "workspace", "knowledge", "notes"],
  "marketing":    ["marketing", "seo", "ads", "advertising", "promotion", "campaign", "social media", "content marketing", "outreach"],
  "education":    ["education", "learn", "study", "tutor", "teach", "student", "school", "course", "lesson", "homework", "language learning", "tutoring"],
  "research":     ["research", "search engine", "academic", "paper", "study", "science", "citation", "journal", "answer engine", "fact check"],
  "business":     ["business", "enterprise", "company", "corporate", "b2b", "sales", "CRM", "executive", "workflow automation"],
  "3d":           ["3d", "3D", "three-dimensional", "3d model", "mesh", "3d generation", "3d art", "text to 3d", "image to 3d"],
  "avatar":       ["avatar", "talking head", "persona", "virtual human", "digital human", "avatar video", "talking avatar"],
  "other":        ["automation", "platform", "hub", "model hub", "no-code"]
};

// Cross-language synonym map (bidirectional expansion)
// Each term expands to all related terms in both languages
const SYNONYMS = {
  // ========== IMAGE GENERATION ==========
  "image":            ["image", "picture", "photo", "art", "illustration", "graphic", "visual", "image generation", "image generator", "ai image", "ai art", "صورة", "صور", "رسم", "تصميم", "فنية", "مولد صور", "توليد الصور"],
  "picture":          ["image", "picture", "photo", "صورة", "صور"],
  "photo":            ["image", "picture", "photo", "photograph", "صورة", "صور", "تصوير", "مولد صور", "توليد الصور"],
  "art":              ["image", "art", "illustration", "artwork", "painting", "رسم", "فنية", "لوحة", "تصميم"],
  "drawing":          ["image", "drawing", "sketch", "art", "رسم", "تصميم", "فنية"],
  "painting":         ["image", "painting", "art", "artwork", "رسم", "لوحة", "فنية"],
  "illustration":     ["image", "art", "illustration", "رسم", "فنية", "تصميم"],
  "sketch":           ["image", "drawing", "sketch", "رسم"],
  "text to image":    ["image generation", "text to image", "image from text", "t2i", "تحويل النص إلى صورة", "نص إلى صورة", "نص لصورة", "تحويل النص لصورة"],
  "t2i":              ["text to image", "image generation", "تحويل النص إلى صورة"],
  "ai image":         ["image generation", "ai art", "ai image", "مولد صور بالذكاء الاصطناعي", "صورة بالذكاء الاصطناعي", "صور بالذكاء الاصطناعي"],
  "ai art":           ["image generation", "ai image", "art", "ai art", "مولد صور", "رسم بالذكاء الاصطناعي", "فن بالذكاء الاصطناعي"],
  "image generator":  ["image generation", "image creator", "photo generator", "ai image", "مولد صور", "مولد صور بالذكاء الاصطناعي", "توليد الصور"],
  "image generation": ["image", "image generator", "ai art", "ai image", "مولد صور", "توليد الصور", "مولد صور بالذكاء الاصطناعي"],
  "image creator":    ["image generation", "image generator", "مولد صور"],
  "photo generator":  ["image generation", "image generator", "مولد صور", "توليد الصور"],
  "art generator":    ["image generation", "ai art", "مولد صور", "رسم بالذكاء الاصطناعي"],
  "make image":       ["image generation", "create image", "generate image", "توليد صور", "إنشاء صورة", "مولد صور"],
  "create image":     ["image generation", "مولد صور", "توليد صورة", "إنشاء صورة"],
  "generate image":   ["image generation", "مولد صور", "توليد الصور"],
  "صورة":             ["image", "صورة", "صور", "رسم", "مولد صور", "توليد الصور", "تصميم", "فنية"],
  "صور":             ["image", "صور", "صورة", "مولد صور", "توليد الصور"],
  "رسم":              ["image", "drawing", "art", "رسم", "رسم بالذكاء الاصطناعي", "تصميم", "فنية", "لوحة"],
  "رسم بالذكاء الاصطناعي": ["image generation", "ai art", "drawing", "رسم", "رسم بالذكاء الاصطناعي", "فن بالذكاء الاصطناعي"],
  "تصميم صورة":       ["image generation", "image design", "create image", "رسم", "تصميم", "مولد صور"],
  "مولد صور":         ["image generation", "image generator", "مولد صور", "مولد صور بالذكاء الاصطناعي", "توليد الصور"],
  "توليد الصور":      ["image generation", "image generation ai", "مولد صور", "مولد صور بالذكاء الاصطناعي", "توليد الصور"],
  "توليد صور":        ["image generation", "توليد الصور", "مولد صور"],
  "مولد صور بالذكاء الاصطناعي": ["image generation", "ai image", "مولد صور", "مولد صور بالذكاء الاصطناعي", "توليد الصور"],
  "صورة بالذكاء الاصطناعي": ["image generation", "ai image", "صورة", "مولد صور", "توليد الصور"],
  "صور بالذكاء":      ["image generation", "ai image", "صور", "مولد صور"],
  "تحويل النص إلى صورة": ["text to image", "image generation", "تحويل النص إلى صورة", "نص إلى صورة", "مولد صور"],
  "تحويل النص لصورة": ["text to image", "image generation", "تحويل النص إلى صورة"],
  "نص إلى صورة":     ["text to image", "image generation", "تحويل النص إلى صورة", "مولد صور"],
  "نص لصورة":        ["text to image", "image generation", "تحويل النص إلى صورة"],
  "إنشاء صورة":      ["image generation", "create image", "مولد صور", "توليد الصور"],
  "فنية":             ["art", "image", "رسم", "فنية", "تصميم"],
  "لوحة":             ["art", "painting", "image", "رسم", "لوحة", "فنية"],
  "تصوير":            ["photo", "image", "photograph", "صورة", "صور", "مولد صور"],

  // ========== VIDEO GENERATION ==========
  "video":            ["video", "movie", "clip", "film", "animation", "footage", "video generation", "ai video", "فيديو", "مقطع", "توليد فيديو"],
  "video generation": ["video", "video generator", "text to video", "t2v", "ai video", "فيديو", "توليد فيديو", "إنشاء فيديو"],
  "text to video":    ["video generation", "text to video", "t2v", "video from text", "توليد فيديو", "إنشاء فيديو", "فيديو من نص"],
  "t2v":              ["text to video", "video generation", "توليد فيديو"],
  "video generator":  ["video generation", "video creator", "توليد فيديو", "إنشاء فيديو", "فيديو"],
  "ai video":         ["video generation", "ai video generator", "فيديو", "توليد فيديو", "فيديو بالذكاء الاصطناعي"],
  "movie":            ["video", "movie", "film", "فيديو", "مقطع"],
  "clip":             ["video", "clip", "short video", "فيديو", "مقطع"],
  "film":             ["video", "film", "movie", "فيديو", "مقطع"],
  "animation":        ["video", "animation", "animated", "فيديو", "حركة", "رسوم متحركة"],
  "فيديو":            ["video", "video generation", "ai video", "فيديو", "مقطع", "توليد فيديو", "فيديو بالذكاء الاصطناعي"],
  "توليد فيديو":      ["video generation", "video generator", "فيديو", "توليد فيديو", "إنشاء فيديو"],
  "إنشاء فيديو":      ["video generation", "create video", "make video", "توليد فيديو", "فيديو"],
  "فيديو بالذكاء الاصطناعي": ["ai video", "video generation", "توليد فيديو", "فيديو", "فيديو بالذكاء الاصطناعي"],
  "مقطع":             ["video", "clip", "فيديو", "مقطع"],
  "مقطع فيديو":       ["video", "clip", "فيديو", "مقطع فيديو"],

  // ========== VOICE / SPEECH ==========
  "voice":            ["voice", "audio", "sound", "speech", "tts", "voiceover", "narration", "voice clone", "dubbing", "صوت", "كلام", "تعليق صوتي"],
  "tts":              ["text to speech", "voice", "speech", "voice synthesis", "تحويل النص إلى كلام", "نص إلى كلام", "صوت"],
  "text to speech":   ["tts", "voice", "speech", "تحويل النص إلى كلام", "نص إلى كلام", "صوت"],
  "speech":           ["voice", "speech", "spoken", "vocal", "صوت", "كلام"],
  "audio":            ["voice", "audio", "sound", "music", "صوت", "صوتي"],
  "voiceover":        ["voice", "voiceover", "narration", "تعليق صوتي", "صوت"],
  "voice clone":      ["voice", "voice cloning", "voice clone", "استنساخ صوت", "صوت", "استنساخ"],
  "voice cloning":    ["voice clone", "voice", "استنساخ صوت", "صوت"],
  "dubbing":          ["voice", "dubbing", "voice dub", "دبلجة", "صوت"],
  "narration":        ["voice", "voiceover", "narration", "تعليق صوتي", "صوت", "رواية"],
  "sound":            ["audio", "voice", "music", "صوت", "صوتي"],
  "صوت":              ["voice", "audio", "sound", "speech", "صوت", "كلام", "تعليق صوتي", "صوت بالذكاء الاصطناعي"],
  "كلام":             ["voice", "speech", "tts", "صوت", "كلام", "تحويل النص إلى كلام"],
  "تعليق صوتي":       ["voice", "voiceover", "narration", "صوت", "تعليق صوتي", "تعليق"],
  "صوت بالذكاء":      ["voice", "ai voice", "صوت", "صوت بالذكاء الاصطناعي", "تعليق صوتي"],
  "صوت بالذكاء الاصطناعي": ["voice", "ai voice", "صوت", "صوت بالذكاء الاصطناعي", "تعليق صوتي"],
  "استنساخ صوت":      ["voice clone", "voice cloning", "صوت", "استنساخ صوت", "صوت بالذكاء الاصطناعي"],
  "استنساخ":          ["clone", "voice clone", "voice cloning", "استنساخ", "استنساخ صوت"],
  "تحويل النص إلى كلام": ["tts", "text to speech", "voice", "تحويل النص إلى كلام", "نص إلى كلام", "صوت"],
  "تحويل النص لكلام": ["tts", "text to speech", "voice", "تحويل النص إلى كلام", "نص إلى كلام", "صوت"],
  "نص إلى كلام":     ["tts", "text to speech", "voice", "تحويل النص إلى كلام", "صوت"],
  "نص لكلام":        ["tts", "text to speech", "voice", "تحويل النص إلى كلام", "صوت"],
  "دبلجة":            ["dubbing", "voice", "دبلجة", "صوت"],

  // ========== MUSIC ==========
  "music":            ["music", "song", "melody", "tune", "track", "beat", "composition", "ai music", "music generator", "موسيقى", "أغنية", "لحن", "تأليف موسيقي"],
  "song":             ["music", "song", "track", "ai song", "موسيقى", "أغنية"],
  "ai music":         ["music", "music generation", "music generator", "ai song", "music ai", "موسيقى", "تأليف موسيقي", "موسيقى بالذكاء الاصطناعي"],
  "music generation": ["music", "ai music", "music generator", "song", "تأليف موسيقي", "موسيقى", "إنشاء موسيقى"],
  "music generator":  ["music", "ai music", "music generation", "song writer", "تأليف موسيقي", "موسيقى", "مولد موسيقى"],
  "songwriter":       ["music", "song", "music generation", "كتابة أغاني", "تأليف موسيقي", "موسيقى"],
  "melody":           ["music", "song", "tune", "لحن", "موسيقى", "أغنية"],
  "tune":             ["music", "song", "melody", "لحن", "موسيقى"],
  "track":            ["music", "song", "track", "موسيقى", "أغنية"],
  "beat":             ["music", "beat", "rhythm", "إيقاع", "موسيقى"],
  "composition":      ["music", "composition", "تأليف", "موسيقى"],
  "موسيقى":           ["music", "song", "ai music", "music generation", "موسيقى", "أغنية", "لحن", "تأليف موسيقي", "موسيقى بالذكاء الاصطناعي"],
  "أغنية":            ["music", "song", "ai music", "موسيقى", "أغنية", "أغاني"],
  "أغاني":            ["music", "song", "ai music", "موسيقى", "أغنية", "أغاني"],
  "لحن":              ["music", "melody", "tune", "موسيقى", "لحن", "ألحان"],
  "ألحان":            ["music", "melody", "tune", "موسيقى", "لحن"],
  "تأليف موسيقي":     ["music composition", "compose music", "music generation", "تأليف موسيقي", "موسيقى", "مؤلف موسيقي"],
  "تأليف":            ["composition", "writing", "music composition", "تأليف", "تأليف موسيقي", "كتابة"],
  "موسيقى بالذكاء الاصطناعي": ["ai music", "music generation", "موسيقى", "تأليف موسيقي", "موسيقى بالذكاء الاصطناعي"],

  // ========== CHAT / ASSISTANT ==========
  "chat":             ["chat", "chatbot", "assistant", "conversation", "talk", "AI assistant", "ask AI", "شات", "دردشة", "محادثة", "مساعد", "شات ذكاء اصطناعي"],
  "chatbot":          ["chat", "chatbot", "conversation", "دردشة", "شات", "محادثة"],
  "assistant":        ["assistant", "AI assistant", "chat", "helper", "مساعد", "مساعد ذكي", "شات"],
  "conversation":     ["chat", "conversation", "talk", "محادثة", "دردشة", "شات"],
  "ai assistant":     ["assistant", "chat", "مساعد", "مساعد ذكاء اصطناعي", "شات ذكاء اصطناعي", "محادثة ذكاء اصطناعي"],
  "talk":             ["chat", "conversation", "محادثة", "دردشة", "تحدث"],
  "ask ai":           ["chat", "AI assistant", "مساعد", "شات", "اسأل الذكاء الاصطناعي"],
  "شات":              ["chat", "chatbot", "conversation", "AI assistant", "شات", "دردشة", "محادثة", "شات ذكاء اصطناعي", "مساعد"],
  "دردشة":            ["chat", "chatbot", "conversation", "شات", "دردشة", "محادثة"],
  "محادثة":           ["chat", "conversation", "talk", "شات", "دردشة", "محادثة"],
  "مساعد":            ["assistant", "helper", "AI assistant", "مساعد", "مساعد ذكي", "شات"],
  "مساعد ذكي":        ["assistant", "AI assistant", "chat", "مساعد", "مساعد ذكاء اصطناعي", "شات"],
  "مساعد ذكاء اصطناعي": ["assistant", "AI assistant", "chat", "مساعد", "مساعد ذكاء اصطناعي", "شات"],
  "شات ذكاء اصطناعي": ["chat", "AI chat", "AI assistant", "شات", "شات ذكاء اصطناعي", "محادثة ذكاء اصطناعي"],
  "محادثة ذكاء اصطناعي": ["chat", "AI chat", "AI conversation", "محادثة ذكاء اصطناعي", "شات", "دردشة"],
  "ذكاء اصطناعي محادثة": ["chat", "AI conversation", "شات", "محادثة ذكاء اصطناعي", "دردشة"],

  // ========== CODING ==========
  "code":             ["code", "coding", "programming", "developer", "software", "script", "code completion", "AI code", "كود", "برمجة", "تطوير", "مطور"],
  "coding":           ["code", "coding", "programming", "developer", "برمجة", "كود", "تطوير", "مطور"],
  "programming":      ["code", "coding", "programming", "developer", "software", "برمجة", "كود", "تطوير", "مطور"],
  "developer":        ["code", "coding", "programming", "developer", "engineer", "programmer", "مطور", "مبرمج", "كود", "برمجة"],
  "software":         ["code", "software", "developer", "برمجيات", "تطوير", "كود", "برمجة"],
  "script":           ["code", "script", "كود", "سكريبت", "برمجة"],
  "code completion":  ["code", "coding", "auto complete", "code suggestion", "إكمال الكود", "إكمال تلقائي للكود", "كود"],
  "ai code":          ["code", "coding", "AI coding", "pair programming", "code generation", "كود بالذكاء الاصطناعي", "كود ذكاء اصطناعي", "برمجة"],
  "pair programming": ["code", "coding", "pair programming", "AI pair programmer", "برمجة", "كود", "البرمجة الزوجية"],
  "كود":              ["code", "coding", "programming", "developer", "كود", "برمجة", "كود بالذكاء الاصطناعي", "تطوير"],
  "برمجة":            ["code", "coding", "programming", "developer", "كود", "برمجة", "تطوير", "مطور", "برمجة ذكاء اصطناعي"],
  "كود بالذكاء الاصطناعي": ["AI code", "code", "coding", "كود", "كود بالذكاء الاصطناعي", "برمجة"],
  "كود ذكاء اصطناعي": ["AI code", "code", "coding", "كود", "كود ذكاء الاصطناعي", "كود بالذكاء الاصطناعي", "برمجة"],
  "مطور":             ["developer", "engineer", "programmer", "مطور", "مبرمج", "كود", "برمجة"],
  "مبرمج":            ["programmer", "developer", "coder", "مبرمج", "مطور", "كود", "برمجة"],
  "تطوير":            ["development", "developer", "programming", "تطوير", "مطور", "كود", "برمجة"],
  "اكواد":            ["code", "codes", "كود", "اكواد", "برمجة"],
  "تطوير برمجيات":   ["software development", "programming", "تطوير برمجيات", "برمجة", "كود", "مطور"],

  // ========== WRITING ==========
  "write":            ["write", "writing", "writer", "content", "article", "blog", "كتابة", "كاتب", "محتوى", "مقال"],
  "writing":          ["write", "writing", "writer", "content", "article", "blog", "copy", "copywriting", "grammar", "editor", "editing", "text", "كتابة", "محتوى", "مقال", "صياغة"],
  "writer":           ["write", "writing", "content", "كاتب", "كتابة", "محتوى"],
  "content":          ["content", "writing", "article", "blog", "copy", "text", "محتوى", "كتابة", "مقال", "نص"],
  "article":          ["article", "blog post", "content", "writing", "مقال", "كتابة", "محتوى"],
  "blog":             ["blog", "blog post", "article", "content", "writing", "مدونة", "كتابة", "مقال", "محتوى"],
  "copy":             ["copy", "copywriting", "content", "writing", "كتابة", "محتوى", "نسخ"],
  "copywriting":      ["copy", "copywriting", "content", "writing", "marketing copy", "كتابة", "كتابة إعلانية", "محتوى"],
  "grammar":          ["grammar", "spelling", "editing", "editor", "قواعد", "نحو", "تدقيق", "تحرير"],
  "editor":           ["editor", "editing", "proofreading", "تحرير", "تدقيق", "محرر"],
  "editing":          ["editing", "editor", "proofreading", "تحرير", "تدقيق", "مراجعة"],
  "كتابة":            ["write", "writing", "content", "article", "كتابة", "محتوى", "مقال", "صياغة", "نص"],
  "كاتب":             ["writer", "author", "content writer", "كاتب", "مؤلف", "كتابة"],
  "محتوى":            ["content", "writing", "article", "blog", "محتوى", "كتابة", "مقال", "نص"],
  "مقال":             ["article", "blog", "post", "مقال", "كتابة", "محتوى", "مدونة"],
  "مقالات":           ["articles", "blog posts", "مقالات", "كتابة", "محتوى"],
  "نص":               ["text", "writing", "content", "نص", "كتابة", "محتوى", "صياغة"],
  "نصوص":             ["texts", "content", "writing", "نصوص", "كتابة", "محتوى"],
  "صياغة":            ["writing", "composition", "formulation", "صياغة", "كتابة", "تأليف"],
  "مدونة":            ["blog", "blogging", "writing", "مدونة", "تدوين", "كتابة", "محتوى"],
  "تدوين":            ["blogging", "blog", "writing", "تدوين", "مدونة", "كتابة"],
  "كتابة محتوى":      ["content writing", "content", "writing", "كتابة محتوى", "كتابة", "محتوى"],
  "تأليف نص":         ["text composition", "writing", "تأليف نص", "كتابة", "صياغة"],

  // ========== DESIGN ==========
  "design":           ["design", "graphic", "visual", "ui", "ux", "logo", "branding", "vector", "mockup", "layout", "تصميم", "ديزاين", "جرافيك", "شعار"],
  "graphic":          ["design", "graphic", "visual", "graphic design", "تصميم", "جرافيك", "ديزاين"],
  "visual":           ["design", "visual", "graphic", "بصري", "تصميم", "جرافيك"],
  "ui":               ["UI", "user interface", "design", "UX", "واجهة المستخدم", "تصميم", "ديزاين"],
  "ux":               ["UX", "user experience", "design", "UI", "تجربة المستخدم", "تصميم"],
  "logo":             ["logo", "design", "branding", "mark", "brand identity", "شعار", "لوجو", "تصميم شعار", "تصميم"],
  "branding":         ["branding", "brand", "design", "logo", "هوية العلامة التجارية", "تصميم", "شعار"],
  "vector":           ["vector", "vector art", "vector graphics", "design", "رسم متجه", "فيكتور", "تصميم"],
  "mockup":          ["mockup", "design", "prototype", "نموذج", "تصميم"],
  "layout":           ["layout", "design", "composition", "تخطيط", "تصميم"],
  "تصميم":            ["design", "graphic", "logo", "UI", "UX", "تصميم", "ديزاين", "جرافيك", "شعار", "تصميم شعار"],
  "ديزاين":           ["design", "design", "graphic", "تصميم", "ديزاين", "جرافيك"],
  "جرافيك":           ["graphic", "design", "graphics", "تصميم", "جرافيك", "ديزاين"],
  "جرافيكس":          ["graphics", "graphic", "design", "تصميم", "جرافيك", "ديزاين"],
  "شعار":             ["logo", "design", "brand", "تصميم", "شعار", "لوجو", "تصميم شعار"],
  "لوجو":             ["logo", "design", "brand", "شعار", "لوجو", "تصميم", "تصميم شعار"],
  "تصميم شعار":       ["logo design", "logo", "brand", "شعار", "لوجو", "تصميم", "تصميم شعار"],
  "شعارات":           ["logos", "brand", "design", "شعارات", "شعار", "تصميم"],
  "تصاميم":           ["designs", "design", "تصاميم", "تصميم", "ديزاين"],
  "مصمم":             ["designer", "design", "مصمم", "تصميم", "ديزاين"],
  "تصميم جرافيك":     ["graphic design", "design", "graphic", "تصميم جرافيك", "تصميم", "جرافيك"],

  // ========== PRODUCTIVITY ==========
  "productivity":     ["productivity", "organize", "task", "note", "schedule", "calendar", "workspace", "knowledge", "notes", "إنتاجية", "تنظيم", "مهام", "تقويم"],
  "organize":         ["organize", "organization", "productivity", "task", "تنظيم", "مهام", "إنتاجية"],
  "task":             ["task", "todo", "productivity", "organize", "مهام", "مهمة", "تنظيم", "إنتاجية"],
  "note":             ["note", "notes", "notepad", "knowledge", "ملاحظة", "ملاحظات", "مذكرة", "تنظيم"],
  "notes":            ["note", "notes", "knowledge", "ملاحظات", "ملاحظة", "تنظيم"],
  "schedule":         ["schedule", "calendar", "plan", "planning", "جدول", "جدولة", "تقويم", "تخطيط"],
  "calendar":         ["calendar", "schedule", "event", "تقويم", "تقويم", "جدول", "جدولة"],
  "workspace":        ["workspace", "work", "productivity", "مساحة عمل", "إنتاجية", "تنظيم"],
  "knowledge":        ["knowledge", "info", "data", "معرفة", "معلومات", "تنظيم"],
  "todo":             ["todo", "task", "checklist", "مهام", "قائمة مهام", "تنظيم", "إنتاجية"],
  "إنتاجية":         ["productivity", "organize", "task", "note", "إنتاجية", "تنظيم", "مهام", "تقويم"],
  "تنظيم":           ["organize", "organization", "productivity", "task", "تنظيم", "إنتاجية", "مهام"],
  "مهام":             ["task", "todo", "productivity", "مهام", "مهمة", "تنظيم", "إنتاجية"],
  "مهمة":             ["task", "todo", "مهمة", "مهام", "تنظيم", "إنتاجية"],
  "تنظيم الوقت":     ["time management", "schedule", "productivity", "تنظيم الوقت", "تنظيم", "إنتاجية", "تقويم"],
  "إدارة المهام":     ["task management", "productivity", "task", "إدارة المهام", "مهام", "تنظيم", "إنتاجية"],
  "ملاحظات":         ["notes", "note", "knowledge", "ملاحظات", "ملاحظة", "تنظيم"],
  "مذكرة":           ["note", "notepad", "ملاحظة", "مذكرة", "تنظيم"],
  "تقويم":           ["calendar", "schedule", "تقويم", "جدول", "جدولة", "إنتاجية"],

  // ========== MARKETING ==========
  "marketing":        ["marketing", "seo", "ads", "advertising", "promotion", "campaign", "social media", "content marketing", "outreach", "تسويق", "إعلانات", "سيو"],
  "seo":              ["SEO", "search engine optimization", "marketing", "ranking", "search", "سيو", "تحسين محركات البحث", "تسويق"],
  "ads":              ["ads", "advertising", "marketing", "ad", "إعلانات", "إعلان", "تسويق", "إعلانات"],
  "advertising":      ["advertising", "ads", "marketing", "campaign", "إعلانات", "تسويق"],
  "promotion":        ["promotion", "marketing", "promotional", "ترويج", "تسويق"],
  "campaign":         ["campaign", "marketing", "ads", "حملة", "حملات", "تسويق", "إعلانات"],
  "social media":     ["social media", "marketing", "social", "وسائط اجتماعية", "سوشيال ميديا", "تسويق"],
  "content marketing": ["content marketing", "marketing", "content", "تسويق بالمحتوى", "تسويق", "محتوى"],
  "outreach":         ["outreach", "marketing", "email", "outreach campaign", "تواصل", "تسويق", "وصول"],
  "cold email":       ["cold email", "email outreach", "marketing", "email", "إيميل بارد", "بريد بارد", "تسويق", "تواصل"],
  "تسويق":           ["marketing", "seo", "ads", "advertising", "تسويق", "تسويق رقمي", "إعلانات", "سيو"],
  "إعلانات":         ["ads", "advertising", "marketing", "إعلانات", "إعلان", "تسويق", "حملات"],
  "إعلان":           ["ad", "advertisement", "ads", "إعلان", "إعلانات", "تسويق"],
  "سيو":             ["SEO", "search engine optimization", "marketing", "سيو", "تحسين محركات البحث", "تسويق"],
  "تسويق رقمي":      ["digital marketing", "marketing", "online marketing", "تسويق رقمي", "تسويق", "تسويق إلكتروني"],
  "تسويق بالمحتوى":  ["content marketing", "marketing", "content", "تسويق بالمحتوى", "تسويق", "محتوى"],
  "حملات":           ["campaigns", "marketing", "ads", "حملات", "حملة", "تسويق", "إعلانات"],
  "تسويقي":          ["marketing", "promotional", "تسويقي", "تسويق"],

  // ========== EDUCATION ==========
  "education":        ["education", "learn", "study", "tutor", "teach", "student", "school", "course", "lesson", "homework", "tutoring", "تعليم", "تعلم", "دراسة", "معلم"],
  "learn":            ["learn", "learning", "study", "education", "tutorial", "course", "تعلم", "تعليم", "دراسة"],
  "learning":         ["learn", "learning", "study", "education", "course", "تعلم", "تعليم", "دراسة"],
  "study":            ["study", "learn", "education", "homework", "research", "دراسة", "تعلم", "تعليم"],
  "tutor":            ["tutor", "tutoring", "teach", "education", "معلم", "مدرس", "تعليم", "تعلم"],
  "tutoring":         ["tutor", "tutoring", "education", "معلم", "مدرس", "تعليم", "تعلم"],
  "teach":            ["teach", "teacher", "education", "tutor", "معلم", "مدرس", "تعليم", "تدرس"],
  "teacher":          ["teacher", "teach", "education", "معلم", "مدرس", "تعليم"],
  "student":          ["student", "education", "learn", "study", "طالب", "طلاب", "تعليم", "تعلم"],
  "school":           ["school", "education", "student", "مدرسة", "تعليم", "معلم", "طالب"],
  "course":           ["course", "class", "lesson", "education", "كورس", "دورة", "تعليم", "درس"],
  "lesson":           ["lesson", "class", "course", "education", "درس", "دروس", "تعليم", "حصة"],
  "homework":         ["homework", "assignment", "education", "student", "واجب", "وظائف", "تعليم", "مدرس"],
  "language":         ["language", "translate", "language learning", "لغة", "لغات", "تعليم", "تعلم"],
  "تعليم":           ["education", "learn", "study", "tutor", "teach", "student", "تعليم", "تعلم", "دراسة", "معلم"],
  "تعلم":            ["learn", "study", "education", "student", "course", "تعلم", "تعليم", "دراسة"],
  "دراسة":           ["study", "learn", "education", "research", "دراسة", "تعلم", "تعليم", "بحث"],
  "معلم":            ["teacher", "tutor", "education", "معلم", "مدرس", "تعليم", "تعلم"],
  "مدرس":            ["teacher", "tutor", "education", "مدرس", "معلم", "تعليم"],
  "طالب":            ["student", "learner", "education", "طالب", "طلاب", "تعليم", "تعلم"],
  "طلاب":            ["students", "learners", "education", "طلاب", "طالب", "تعليم", "تعلم"],
  "منهج":            ["curriculum", "syllabus", "education", "course", "منهج", "تعليم", "دورة"],
  "دورة":            ["course", "class", "education", "دورة", "كورس", "تعليم", "درس"],
  "دورات":           ["courses", "classes", "education", "دورات", "دورة", "كورسات", "تعليم"],
  "تعليمي":          ["educational", "education", "تعليمي", "تعليم", "تعلم"],

  // ========== RESEARCH ==========
  "research":         ["research", "search", "academic", "paper", "study", "science", "citation", "journal", "answer engine", "fact check", "بحث", "دراسة", "تحليل", "تحقيق"],
  "search engine":    ["search", "search engine", "answer engine", "research", "AI search", "محرك بحث", "بحث", "محرك إجابات"],
  "answer engine":    ["search", "AI search", "research", "محرك إجابات", "بحث", "محرك بحث"],
  "academic":         ["academic", "research", "paper", "scholar", "أكاديمي", "بحث", "علمي"],
  "paper":            ["paper", "research", "academic", "study", "ورقة بحثية", "بحث", "دراسة"],
  "science":          ["science", "research", "study", "علم", "علوم", "بحث", "دراسة"],
  "citation":         ["citation", "reference", "research", "academic", "اقتباس", "مرجع", "بحث", "أكاديمي"],
  "journal":          ["journal", "paper", "research", "academic", "مجلة", "دورية", "بحث"],
  "fact check":       ["fact check", "research", "verify", "تحقق", "تدقيق", "بحث", "تحقق من الحقائق"],
  "بحث":             ["search", "research", "study", "investigation", "find", "lookup", "بحث", "دراسة", "تحقيق", "تحليل"],
  "البحث":           ["search", "research", "study", "البحث", "بحث", "دراسة", "تحقيق"],
  "تحقيق":           ["research", "investigation", "journalism", "تحقيق", "بحث", "دراسة", "تحقيق صحفي"],
  "تحليل":           ["analysis", "research", "study", "analytics", "تحليل", "بحث", "دراسة"],
  "دراسات":          ["studies", "research", "papers", "دراسات", "دراسة", "بحث"],
  "محقق":            ["researcher", "investigator", "محقق", "باحث", "بحث"],
  "استكشاف":         ["exploration", "research", "discover", "استكشاف", "بحث", "اكتشاف"],
  "ابحاث":           ["research", "studies", "ابحاث", "بحث", "دراسات", "أبحاث"],

  // ========== BUSINESS ==========
  "business":         ["business", "enterprise", "company", "corporate", "b2b", "sales", "CRM", "executive", "workflow automation", "أعمال", "شركات", "مؤسسات", "بيزنس"],
  "enterprise":       ["enterprise", "business", "corporate", "company", "مؤسسي", "أعمال", "شركات", "مؤسسات"],
  "company":          ["company", "business", "corporate", "شركة", "شركات", "أعمال"],
  "corporate":        ["corporate", "business", "enterprise", "company", "شركات", "أعمال", "مؤسسي"],
  "b2b":              ["B2B", "business to business", "sales", "business", "بيزنس", "أعمال", "مبيعات"],
  "sales":            ["sales", "business", "selling", "مبيعات", "بيع", "أعمال"],
  "crm":              ["CRM", "customer relationship", "sales", "business", "إدارة علاقات العملاء", "مبيعات", "أعمال"],
  "executive":        ["executive", "business", "leader", "manager", "تنفيذي", "أعمال", "مدير"],
  "workflow":         ["workflow", "automation", "business", "سير العمل", "أتمتة", "أعمال"],
  "automation":       ["automation", "workflow", "business", "no-code", "أتمتة", "أتمتة سير العمل", "أعمال", "بدون كود"],
  "no-code":          ["no-code", "no code", "nocode", "automation", "visual programming", "بدون كود", "أتمتة", "برمجة بدون كود"],
  "أعمال":           ["business", "enterprise", "company", "corporate", "b2b", "sales", "أعمال", "شركات", "مؤسسات", "بيزنس"],
  "شركات":           ["companies", "business", "enterprise", "corporate", "شركات", "شركة", "أعمال", "مؤسسات"],
  "شركة":            ["company", "business", "corporate", "شركة", "شركات", "أعمال"],
  "مؤسسات":          ["institutions", "enterprise", "organizations", "corporate", "مؤسسات", "مؤسسة", "أعمال", "شركات"],
  "بيزنس":           ["business", "بيزنس", "أعمال", "شركات"],
  "تجاري":           ["commercial", "business", "trade", "تجاري", "أعمال", "تجارة"],
  "مؤسسي":           ["enterprise", "institutional", "corporate", "مؤسسي", "مؤسسات", "أعمال", "شركات"],
  "مبيعات":          ["sales", "selling", "business", "مبيعات", "بيع", "أعمال"],
  "بيزنس":           ["business", "بيزنس", "أعمال", "شركات"],

  // ========== 3D ==========
  "3d":               ["3D", "3d", "three-dimensional", "3d model", "3d art", "mesh", "3d generation", "text to 3d", "image to 3d", "render", "three-d", "ثلاثي الأبعاد", "3دي", "نماذج ثلاثية الأبعاد"],
  "three-dimensional": ["3D", "3d", "three-dimensional", "3d model", "three-d", "ثلاثي الأبعاد", "3دي"],
  "3d model":         ["3D model", "3d", "mesh", "model", "three-dimensional", "نموذج ثلاثي الأبعاد", "3دي", "نموذج 3d"],
  "mesh":             ["mesh", "3D model", "3d", "network", "شبكة", "نموذج ثلاثي", "3دي"],
  "3d generation":    ["3D", "3d", "3d generation", "text to 3d", "image to 3d", "model generation", "توليد ثلاثي الأبعاد", "3دي", "نماذج ثلاثية الأبعاد"],
  "3d art":           ["3D art", "3d", "art", "three-dimensional", "فن ثلاثي الأبعاد", "3دي", "رسم ثلاثي"],
  "text to 3d":       ["3D generation", "text to 3d", "t23d", "3d", "تحويل النص إلى 3d", "توليد ثلاثي الأبعاد", "3دي"],
  "image to 3d":      ["3D generation", "image to 3d", "i23d", "3d", "تحويل الصورة إلى 3d", "توليد ثلاثي الأبعاد", "3دي"],
  "render":           ["render", "3D rendering", "3d", "visualization", "تقديم", "عرض", "3دي", "تصيير"],
  "نموذج ثلاثي":     ["3D model", "3d", "three-dimensional", "نموذج ثلاثي", "3دي", "نموذج ثلاثي الأبعاد"],
  "نموذج ثلاثي الأبعاد": ["3D model", "three-dimensional model", "3d", "نموذج ثلاثي الأبعاد", "3دي"],
  "نماذج ثلاثية الأبعاد": ["3D models", "three-dimensional", "3d", "نماذج ثلاثية الأبعاد", "3دي"],
  "3دي":             ["3D", "3d", "three-dimensional", "3دي", "ثلاثي الأبعاد", "نماذج ثلاثية الأبعاد"],
  "موديل 3d":        ["3D model", "3d", "موديل 3d", "نموذج ثلاثي", "3دي"],
  "تصميم ثلاثي":     ["3D design", "3d", "three-dimensional design", "تصميم ثلاثي", "3دي", "تصميم ثلاثي الأبعاد"],

  // ========== AVATAR ==========
  "avatar":           ["avatar", "talking head", "persona", "virtual human", "digital human", "avatar video", "talking avatar", "أفاتار", "صور رمزية", "شخصية افتراضية", "شخصية رقمية"],
  "talking head":     ["avatar", "talking head", "talking avatar", "أفاتار", "صور رمزية", "وجوه ناطقة"],
  "talking avatar":   ["avatar", "talking head", "talking avatar", "أفاتار", "صور رمزية", "وجوه ناطقة"],
  "persona":          ["persona", "avatar", "character", "شخصية", "أفاتار", "صور رمزية"],
  "virtual human":    ["virtual human", "avatar", "digital human", "بشر افتراضي", "أفاتار", "شخصية افتراضية"],
  "digital human":    ["digital human", "avatar", "virtual human", "بشر رقمي", "أفاتار", "شخصية افتراضية"],
  "avatar video":     ["avatar", "talking avatar", "avatar video", "فيديو أفاتار", "أفاتار", "صور رمزية"],
  "أفاتار":           ["avatar", "talking head", "persona", "virtual human", "أفاتار", "صور رمزية", "شخصية افتراضية", "شخصية رقمية"],
  "افاتار":           ["avatar", "talking head", "persona", "أفاتار", "صور رمزية", "شخصية افتراضية"],
  "صور رمزية":       ["avatar", "avatars", "talking head", "صور رمزية", "أفاتار", "شخصية افتراضية"],
  "شخصية افتراضية":  ["virtual human", "avatar", "digital human", "شخصية افتراضية", "أفاتار", "شخصية رقمية"],
  "شخصية رقمية":     ["digital human", "avatar", "virtual human", "شخصية رقمية", "أفاتار", "شخصية افتراضية"],
  "رمزية":           ["avatar", "avatars", "رمزية", "صور رمزية", "أفاتار"],

  // ========== TRANSLATION (not a category but should be understood) ==========
  "translate":        ["translate", "translation", "translator", "translating", "language", "localize", "localization", "ترجمة", "مترجم", "ترجم", "لغة", "تحويل النص"],
  "translation":      ["translate", "translation", "translator", "translating", "language", "localization", "ترجمة", "مترجم", "ترجم", "لغة", "تحويل النص"],
  "translator":       ["translate", "translation", "translator", "translating", "language", "مترجم", "ترجمة", "ترجم", "لغة"],
  "translating":      ["translate", "translation", "translator", "translating", "language", "ترجمة", "مترجم", "ترجم", "لغة"],
  "language translation": ["translate", "translation", "translator", "language", "ترجمة", "مترجم", "لغة", "ترجمة لغات"],
  "ترجمة":            ["translate", "translation", "translator", "translating", "language", "ترجمة", "مترجم", "ترجم", "لغة", "تحويل النص"],
  "مترجم":            ["translate", "translator", "translation", "language", "مترجم", "ترجمة", "ترجم", "لغة"],
  "ترجم":             ["translate", "translator", "translation", "ترجم", "مترجم", "ترجمة", "لغة"],
  "ترجمة نص":         ["text translation", "translate text", "translation", "ترجمة نص", "ترجمة", "مترجم", "نص"],
  "ترجمة ملفات":      ["file translation", "document translation", "translate files", "ترجمة ملفات", "ترجمة", "مترجم", "ملفات"],
  "تحويل النص":       ["text conversion", "text translate", "convert text", "تحويل النص", "ترجمة", "نص", "تحويل"],
  "لغة":              ["language", "translate", "translation", "لغة", "لغات", "ترجمة", "مترجم"]
};

// Bilingual category anchors — strongest phrases per category.
// Used for phrase-based category matching (multi-word phrases win over single words).
const CATEGORY_ANCHORS = {
  "chat": [
    "chat", "chatbot", "assistant", "ai assistant", "conversation", "talk", "ask ai", "ask",
    "شات", "دردشة", "محادثة", "مساعد", "مساعد ذكي", "مساعد ذكاء اصطناعي", "تحدث",
    "شات ذكاء اصطناعي", "محادثة ذكاء اصطناعي", "ذكاء اصطناعي محادثة", "دردشة ذكاء اصطناعي"
  ],
  "image-gen": [
    "image generation", "image generator", "text to image", "ai image", "ai art", "ai image generator",
    "image", "picture", "photo", "art", "drawing", "painting", "illustration", "sketch",
    "photo generator", "art generator", "create image", "generate image", "image creator", "make image", "image from text",
    "صورة", "صور", "رسم", "فنية", "لوحة", "تصوير", "رسم بالذكاء الاصطناعي",
    "تصميم صورة", "مولد صور", "توليد الصور", "توليد صور", "إنشاء صورة", "مولد صور بالذكاء الاصطناعي",
    "صورة بالذكاء الاصطناعي", "صور بالذكاء الاصطناعي", "صور بالذكاء",
    "تحويل النص إلى صورة", "تحويل النص لصورة", "نص إلى صورة", "نص لصورة", "صورة من نص"
  ],
  "video-gen": [
    "video generation", "video generator", "text to video", "ai video", "ai video generator",
    "video", "movie", "film", "clip", "animation",
    "create video", "make video", "video creator", "video from text",
    "فيديو", "مقطع", "مقطع فيديو", "توليد فيديو", "إنشاء فيديو", "فيديو بالذكاء الاصطناعي", "فيديو من نص"
  ],
  "voice": [
    "voice", "speech", "audio", "tts", "text to speech", "voiceover", "voice clone", "voice cloning", "narration", "dubbing", "sound",
    "صوت", "كلام", "تعليق صوتي", "استنساخ صوت", "استنساخ", "صوت بالذكاء", "صوت بالذكاء الاصطناعي",
    "تحويل النص إلى كلام", "تحويل النص لكلام", "نص إلى كلام", "نص لكلام", "دبلجة"
  ],
  "music": [
    "music generation", "music generator", "ai music", "music ai",
    "music", "song", "melody", "tune", "track", "beat", "composition", "songwriter",
    "موسيقى", "أغنية", "أغاني", "لحن", "ألحان", "تأليف موسيقي", "تأليف", "موسيقى بالذكاء الاصطناعي"
  ],
  "coding": [
    "code", "coding", "programming", "developer", "software", "script", "code completion", "ai code", "pair programming", "ai coding",
    "كود", "برمجة", "مبرمج", "مطور", "مطورين", "تطوير", "اكواد", "برمجي", "تطوير برمجيات",
    "كود بالذكاء الاصطناعي", "كود ذكاء اصطناعي", "برمجة ذكاء اصطناعي"
  ],
  "writing": [
    "writing", "writer", "content", "article", "blog", "copy", "copywriting", "grammar", "editor", "editing", "write",
    "كتابة", "كاتب", "محتوى", "مقال", "مقالات", "نص", "نصوص", "صياغة", "مدونة", "تدوين", "كتابة محتوى", "تأليف نص", "كتابة إعلانية"
  ],
  "design": [
    "design", "graphic", "visual", "ui", "ux", "logo", "branding", "vector", "mockup", "layout",
    "تصميم", "ديزاين", "جرافيك", "جرافيكس", "شعار", "لوجو", "شعارات", "تصاميم", "مصمم", "تصميم شعار", "تصميم جرافيك"
  ],
  "productivity": [
    "productivity", "organize", "task", "todo", "note", "notes", "schedule", "calendar", "workspace", "knowledge", "task management", "time management",
    "إنتاجية", "تنظيم", "مهام", "مهمة", "ملاحظات", "مذكرة", "تقويم", "تنظيم الوقت", "إدارة المهام", "إدارة الوقت"
  ],
  "marketing": [
    "marketing", "seo", "ads", "advertising", "promotion", "campaign", "social media", "outreach", "content marketing", "digital marketing", "online marketing",
    "تسويق", "إعلانات", "إعلان", "سيو", "تسويق رقمي", "تسويق بالمحتوى", "تسويق إلكتروني", "حملات", "تسويقي"
  ],
  "education": [
    "education", "learn", "learning", "study", "tutor", "teacher", "student", "course", "homework", "language learning", "tutoring",
    "تعليم", "تعلم", "تعليمي", "تعليمي ذكاء", "تعليم ذكاء اصطناعي", "دراسة", "معلم", "مدرس", "طالب", "طلاب", "منهج", "دورة", "دورات", "كورس"
  ],
  "research": [
    "research", "search engine", "answer engine", "academic", "paper", "science", "citation", "journal", "fact check",
    "بحث", "البحث", "تحقيق", "تحليل", "دراسات", "محقق", "استكشاف", "ابحاث", "أبحاث", "محرك بحث", "محرك إجابات"
  ],
  "business": [
    "business", "enterprise", "company", "b2b", "sales", "crm", "executive", "workflow", "automation", "no-code", "no code", "nocode",
    "أعمال", "شركات", "شركة", "مؤسسات", "بيزنس", "تجاري", "مؤسسي", "مبيعات", "أتمتة", "بدون كود"
  ],
  "3d": [
    "3d", "3d model", "3d art", "3d generation", "text to 3d", "image to 3d", "mesh", "render", "three-dimensional", "3d model generation", "model generation",
    "3دي", "نموذج ثلاثي", "نموذج ثلاثي الأبعاد", "نماذج ثلاثية الأبعاد", "نماذج", "موديل 3d", "تصميم ثلاثي", "ثلاثي الأبعاد", "تصميم ثلاثي الأبعاد", "نموذج 3d"
  ],
  "avatar": [
    "avatar", "talking head", "talking avatar", "persona", "virtual human", "digital human", "avatar video",
    "أفاتار", "افاتار", "صور رمزية", "شخصية افتراضية", "شخصية رقمية", "رمزية", "وجوه ناطقة"
  ],
  "other": [
    "automation", "platform", "hub", "model hub", "no-code", "ai hub",
    "أتمتة", "منصة", "مركز", "مركز نماذج", "بدون كود", "مركز ذكاء اصطناعي"
  ]
};

// Backwards-compat: ARABIC_TERMS is now derived from SYNONYMS
// (kept as empty object for any external code that might reference it)
const ARABIC_TERMS = (() => {
  const m = {};
  for (const cat of CATEGORIES) {
    const concepts = CATEGORY_CONCEPTS[cat.id] || [];
    for (const c of concepts) {
      // No-op placeholder; mapping is via SYNONYMS
    }
  }
  return m;
})();

// ============================================
// Tool aliases: Arabic transliterations of popular tool names
// ============================================
const TOOL_ALIASES = {
  "chatgpt": ["شات جي بي تي", "تشات جي بي تي", "شات", "جي بي تي"],
  "claude": ["كلود", "كلود شات"],
  "midjourney": ["ميدجورني", "ميد جورني"],
  "dalle": ["دال اي", "دالي"],
  "gemini": ["جيميني", "توأم", "جمني"],
  "perplexity": ["بيربلكستي", "بيربلكسيتي"],
  "elevenlabs": ["اليفن لابز", "اليفن لابز"],
  "suno": ["سونو", "صنو"],
  "sora": ["سورا"],
  "cursor": ["كورسر"],
  "copilot": ["كوبايلوت", "جيتهب كوبايلوت"],
  "runway": ["رانواي", "رنواي"],
  "pika": ["بيكا"],
  "leonardo": ["ليوناردو"],
  "ideogram": ["ايديوجرام"],
  "firefly": ["فايرفلاي", "فاير فلاي"],
  "stability": ["ستابيليتي"],
  "flux": ["فلوكس"],
  "recraft": ["ريكraft"],
  "krea": ["كريا"],
  "canva": ["كانفا", "كنva"],
  "jasper": ["جاسبر"],
  "copyai": ["كوبي اي", "كوبي"],
  "grammarly": ["جرامارلي"],
  "notion-ai": ["نوشن", "نوشن ذكاء"],
  "writesonic": ["رايت سونيك"],
  "rytr": ["ريتر"],
  "codeium": ["كوديم"],
  "tabnine": ["تاب ناين"],
  "replit": ["ريبلت"],
  "elevenlabs-music": ["اليفن لابز موسيقى"],
  "speechify": ["سبيتشيفاي", "speechify", "whisper", "wisper", "سبيسفاي"],
  "huggingface": ["huggingface", "hf", "hugging face", "hugging"],
  "mem": ["ميم"],
  "reclaim": ["ريكلايم"],
  "motion": ["موشن"],
  "taskade": ["تاسكاد"],
  "raycast": ["راي كاست"],
  "fyxer": ["فايكر"],
  "khanmigo": ["خانميجو"],
  "duolingo": ["دولينجو"],
  "quizlet": ["كويزلت"],
  "photomath": ["فوتو ماث", "فوتومات"],
  "surfer": ["سرفر"],
  "adcreative": ["ادكرييتيف"],
};

// ============================================
// Tools Database
// ============================================
const TOOLS = [
  // ===== AI Chat (4) =====
  {
    id: "chatgpt",
    name: "ChatGPT",
    tagline: "The world's most popular AI assistant",
    description: "ChatGPT by OpenAI is a versatile AI assistant for writing, coding, analysis, and creative work. Powered by GPT-4o and the latest GPT models.",
    category: "chat",
    url: "https://chat.openai.com",
    logo: "https://favicon.show/openai.com",
    rating: 4.8,
    reviews: 120000,
    pricing: "freemium",
    priceDetail: "Free, $20/mo for Plus",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2022-11-30",
    updatedDate: "2026-07-10",
    tags: ["assistant", "chat", "OpenAI"],
    featured: true
  },
  {
    id: "claude",
    name: "Claude",
    tagline: "Safe, capable AI from Anthropic",
    description: "Claude is a next-generation AI assistant built by Anthropic. Excels at reasoning, analysis, coding, and creative writing with a 200K token context window.",
    category: "chat",
    url: "https://claude.ai",
    logo: "https://favicon.show/anthropic.com",
    rating: 4.9,
    reviews: 65000,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-03-04",
    updatedDate: "2026-07-09",
    tags: ["chat", "reasoning", "Anthropic"]
  },
  {
    id: "gemini",
    name: "Gemini",
    tagline: "Google's multimodal AI assistant",
    description: "Gemini is Google's most capable AI. Multimodal by design, with deep integration across Google Workspace, Search, and developer APIs.",
    category: "chat",
    url: "https://gemini.google.com",
    logo: "https://favicon.show/google.com",
    rating: 4.7,
    reviews: 42000,
    pricing: "freemium",
    priceDetail: "Free, $20/mo Advanced",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-12-06",
    updatedDate: "2026-07-08",
    tags: ["chat", "Google", "multimodal"]
  },
  {
    id: "mistral",
    name: "Le Chat by Mistral",
    tagline: "Fast open-weight AI assistant",
    description: "Le Chat is Mistral AI's conversational assistant, powered by frontier open-weight models. Fast, multilingual, and privacy-friendly.",
    category: "chat",
    url: "https://chat.mistral.ai",
    logo: "https://favicon.show/mistral.ai",
    rating: 4.6,
    reviews: 4200,
    pricing: "freemium",
    priceDetail: "Free tier, then $14.99/mo",
    trending: true,
    topRated: false,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-03-10",
    updatedDate: "2026-07-09",
    tags: ["chat", "open weights", "Mistral"]
  },

  // ===== AI Image Generation (8) =====
  {
    id: "midjourney",
    name: "Midjourney",
    tagline: "AI art generation with stunning quality",
    description: "Midjourney is an independent research lab producing one of the world's most advanced AI image generators. Create breathtaking artwork from text prompts.",
    category: "image-gen",
    url: "https://midjourney.com",
    logo: "https://favicon.show/midjourney.com",
    rating: 4.9,
    reviews: 45000,
    pricing: "paid",
    priceDetail: "From $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2022-07-12",
    updatedDate: "2026-07-09",
    tags: ["art", "image generation", "text-to-image"]
  },
  {
    id: "dalle",
    name: "DALL-E 3",
    tagline: "OpenAI's most capable image generator",
    description: "DALL-E 3 from OpenAI transforms detailed text descriptions into highly accurate images. Integrated with ChatGPT for natural prompt refinement.",
    category: "image-gen",
    url: "https://openai.com/dall-e-3",
    logo: "https://favicon.show/openai.com",
    rating: 4.8,
    reviews: 38000,
    pricing: "freemium",
    priceDetail: "Free via Bing, $20/mo in ChatGPT Plus",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-10-01",
    updatedDate: "2026-07-07",
    tags: ["art", "image generation", "OpenAI"]
  },
  {
    id: "leonardo",
    name: "Leonardo.AI",
    tagline: "Production-ready AI art for creators",
    description: "Leonardo.AI gives creators full control over AI image generation with custom models, fine-tuning, and production-ready assets for games, marketing, and design.",
    category: "image-gen",
    url: "https://leonardo.ai",
    logo: "https://favicon.show/leonardo.ai",
    rating: 4.7,
    reviews: 18900,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-04-18",
    updatedDate: "2026-07-01",
    tags: ["image generation", "game assets", "production"]
  },
  {
    id: "ideogram",
    name: "Ideogram",
    tagline: "AI image generation with reliable text",
    description: "Ideogram is a free AI image generator that excels at rendering text within images. Perfect for posters, logos, and designs with typography.",
    category: "image-gen",
    url: "https://ideogram.ai",
    logo: "https://favicon.show/ideogram.ai",
    rating: 4.6,
    reviews: 9500,
    pricing: "freemium",
    priceDetail: "Free tier available",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-02-10",
    updatedDate: "2026-06-30",
    tags: ["image generation", "typography", "logos"]
  },
  {
    id: "firefly",
    name: "Adobe Firefly",
    tagline: "Creative AI from Adobe",
    description: "Adobe Firefly is a family of creative generative AI models coming to Adobe products. Generate images, text effects, and creative assets safely for commercial use.",
    category: "image-gen",
    url: "https://firefly.adobe.com",
    logo: "https://favicon.show/adobe.com",
    rating: 4.6,
    reviews: 22000,
    pricing: "freemium",
    priceDetail: "Free tier, then $4.99/mo",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-06-15",
    updatedDate: "2026-07-03",
    tags: ["image generation", "commercial", "Adobe"]
  },
  {
    id: "stability",
    name: "Stable Diffusion",
    tagline: "Open-source image generation",
    description: "Stable Diffusion is a latent text-to-image diffusion model that generates photo-realistic images from text. Open source and runs locally on your own hardware.",
    category: "image-gen",
    url: "https://stability.ai",
    logo: "https://favicon.show/stability.ai",
    rating: 4.7,
    reviews: 27000,
    pricing: "free",
    priceDetail: "Open source, free",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2022-08-22",
    updatedDate: "2026-06-25",
    tags: ["image generation", "open source", "self-hosted"]
  },
  {
    id: "flux",
    name: "Flux by Black Forest Labs",
    tagline: "State-of-the-art open image model",
    description: "Flux is a powerful image generation model from Black Forest Labs. Known for photorealism, prompt adherence, and open weights available for self-hosting.",
    category: "image-gen",
    url: "https://blackforestlabs.ai",
    logo: "https://favicon.show/blackforestlabs.ai",
    rating: 4.8,
    reviews: 4800,
    pricing: "freemium",
    priceDetail: "Free tier, then usage-based",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-22",
    updatedDate: "2026-07-10",
    tags: ["image generation", "open weights", "photorealistic"]
  },
  {
    id: "krea",
    name: "Krea AI",
    tagline: "Realtime AI image generation",
    description: "Krea AI brings realtime generation to images and video. Sketch and see AI fill in your vision instantly. Includes enhancer, logo, and video tools.",
    category: "image-gen",
    url: "https://krea.ai",
    logo: "https://favicon.show/krea.ai",
    rating: 4.6,
    reviews: 5400,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-02-14",
    updatedDate: "2026-07-04",
    tags: ["image generation", "realtime", "sketch"]
  },

  // ===== AI Video Generation (6) =====
  {
    id: "runway",
    name: "Runway",
    tagline: "Next-gen AI video generation & editing",
    description: "Runway is an applied AI research company building tools that make video production faster and more accessible. Generate videos from text, images, or existing clips with state-of-the-art AI models like Gen-3 Alpha.",
    category: "video-gen",
    url: "https://runwayml.com",
    logo: "https://favicon.show/runwayml.com",
    rating: 4.8,
    reviews: 12420,
    pricing: "freemium",
    priceDetail: "Free tier, then $12/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-04-12",
    updatedDate: "2026-07-08",
    tags: ["video generation", "text-to-video", "editing"]
  },
  {
    id: "pika",
    name: "Pika",
    tagline: "Create stunning videos from text and images",
    description: "Pika is a video generation platform that lets you create and edit videos in new ways. Use text prompts, images, or existing videos to generate cinematic content in seconds.",
    category: "video-gen",
    url: "https://pika.art",
    logo: "https://favicon.show/pika.art",
    rating: 4.7,
    reviews: 8200,
    pricing: "freemium",
    priceDetail: "Free tier available",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-07-22",
    updatedDate: "2026-07-05",
    tags: ["video generation", "creative"]
  },
  {
    id: "descript",
    name: "Descript",
    tagline: "Edit videos and podcasts like a document",
    description: "Descript is an all-in-one video and podcast editor that uses AI to transcribe, edit, and produce content. Remove filler words, overdub voices, and more.",
    category: "video-gen",
    url: "https://descript.com",
    logo: "https://favicon.show/descript.com",
    rating: 4.7,
    reviews: 5400,
    pricing: "freemium",
    priceDetail: "Free tier, then $12/mo",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-05-20",
    updatedDate: "2026-07-02",
    tags: ["video", "podcast", "transcription", "editing"]
  },
  {
    id: "invideo",
    name: "InVideo AI",
    tagline: "Turn any idea into a video instantly",
    description: "InVideo AI creates publish-worthy videos from text prompts. Generate scripts, visuals, voiceovers, and edits automatically with simple text commands.",
    category: "video-gen",
    url: "https://invideo.io",
    logo: "https://favicon.show/invideo.io",
    rating: 4.5,
    reviews: 7800,
    pricing: "freemium",
    priceDetail: "Free tier available",
    trending: true,
    topRated: false,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-08-30",
    updatedDate: "2026-05-20",
    tags: ["video", "script-to-video", "social"]
  },
  {
    id: "sora",
    name: "Sora",
    tagline: "OpenAI's text-to-video model",
    description: "Sora is OpenAI's text-to-video model that creates realistic and imaginative scenes from text instructions. Up to 60 seconds of high-fidelity video.",
    category: "video-gen",
    url: "https://openai.com/sora",
    logo: "https://favicon.show/openai.com",
    rating: 4.9,
    reviews: 14200,
    pricing: "paid",
    priceDetail: "ChatGPT Plus $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-05-15",
    updatedDate: "2026-07-10",
    tags: ["video generation", "OpenAI", "cinematic"]
  },
  {
    id: "lumen5",
    name: "Lumen5",
    tagline: "Turn text into video in minutes",
    description: "Lumen5 is an AI video maker that turns blog posts, articles, and scripts into engaging social videos. Used by 800,000+ brands worldwide.",
    category: "video-gen",
    url: "https://lumen5.com",
    logo: "https://favicon.show/lumen5.com",
    rating: 4.4,
    reviews: 4200,
    pricing: "freemium",
    priceDetail: "Free tier, then $25/mo",
    trending: false,
    topRated: false,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-03-15",
    updatedDate: "2026-04-18",
    tags: ["video", "text-to-video", "social", "marketing"]
  },

  // ===== AI Voice (7) =====
  {
    id: "elevenlabs",
    name: "ElevenLabs",
    tagline: "The most realistic AI voice platform",
    description: "ElevenLabs creates lifelike AI voices in any language. Voice cloning, text-to-speech, dubbing, and a massive voice library for creators.",
    category: "voice",
    url: "https://elevenlabs.io",
    logo: "https://favicon.show/elevenlabs.io",
    rating: 4.8,
    reviews: 24000,
    pricing: "freemium",
    priceDetail: "Free tier, then $5/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-01-15",
    updatedDate: "2026-07-09",
    tags: ["voice", "TTS", "voice cloning", "dubbing"],
    featured: true
  },
  {
    id: "murf",
    name: "Murf AI",
    tagline: "Studio-quality AI voiceovers",
    description: "Murf AI offers 200+ studio-quality AI voices in 20+ languages. Perfect for videos, podcasts, e-learning, and presentations.",
    category: "voice",
    url: "https://murf.ai",
    logo: "https://favicon.show/murf.ai",
    rating: 4.6,
    reviews: 8200,
    pricing: "freemium",
    priceDetail: "Free trial, then $23/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-04-08",
    updatedDate: "2026-05-10",
    tags: ["voice", "voiceover", "studio", "e-learning"]
  },
  {
    id: "playht",
    name: "Play.ht",
    tagline: "AI voice generator with ultra realism",
    description: "Play.ht converts text to speech using AI voices. 600+ voices in 140+ languages with voice cloning and API access.",
    category: "voice",
    url: "https://play.ht",
    logo: "https://favicon.show/play.ht",
    rating: 4.6,
    reviews: 6700,
    pricing: "freemium",
    priceDetail: "Free tier, then $31.20/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-02-22",
    updatedDate: "2026-04-15",
    tags: ["voice", "TTS", "API", "multilingual"]
  },
  {
    id: "resemble",
    name: "Resemble AI",
    tagline: "Voice AI for real-time applications",
    description: "Resemble AI builds custom voice clones and offers real-time TTS for games, IVR, and apps. Emotion control and watermarking included.",
    category: "voice",
    url: "https://resemble.ai",
    logo: "https://favicon.show/resemble.ai",
    rating: 4.5,
    reviews: 4100,
    pricing: "paid",
    priceDetail: "From $0.006/sec",
    trending: true,
    topRated: false,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-05-15",
    updatedDate: "2026-03-20",
    tags: ["voice", "real-time", "games", "emotion"]
  },
  {
    id: "wellsaid",
    name: "WellSaid Labs",
    tagline: "AI voice for teams",
    description: "WellSaid Labs turns text into voice in real-time. Studio-quality AI voices for videos, training, and corporate content with team collaboration.",
    category: "voice",
    url: "https://wellsaidlabs.com",
    logo: "https://favicon.show/wellsaidlabs.com",
    rating: 4.6,
    reviews: 3800,
    pricing: "paid",
    priceDetail: "From $49/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-03-30",
    updatedDate: "2026-04-25",
    tags: ["voice", "teams", "studio", "corporate"]
  },
  {
    id: "suno-voice",
    name: "Suno Bark",
    tagline: "Open text-to-speech by Suno",
    description: "Suno Bark is an open-source transformer-based TTS model. High quality, multilingual, free for research and commercial use.",
    category: "voice",
    url: "https://suno.ai",
    logo: "https://favicon.show/suno.ai",
    rating: 4.6,
    reviews: 2100,
    pricing: "free",
    priceDetail: "Open source, free",
    trending: true,
    topRated: false,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-12",
    updatedDate: "2026-07-08",
    tags: ["voice", "open source", "TTS", "research"]
  },
  {
    id: "speechify",
    name: "Speechify",
    tagline: "AI text-to-speech for everyone",
    description: "Speechify is a top-rated text-to-speech app used by 20M+ people. Read faster, listen to documents, web pages, and PDFs in 30+ voices.",
    category: "voice",
    url: "https://speechify.com",
    logo: "https://favicon.show/speechify.com",
    rating: 4.6,
    reviews: 28000,
    pricing: "freemium",
    priceDetail: "Free tier, then $11.58/mo",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-06-12",
    updatedDate: "2026-06-30",
    tags: ["voice", "TTS", "accessibility", "mobile"]
  },

  // ===== AI Music (6) =====
  {
    id: "suno",
    name: "Suno",
    tagline: "AI that makes any song you can imagine",
    description: "Suno turns your ideas into full songs with vocals, instruments, and lyrics. Just describe what you want and listen.",
    category: "music",
    url: "https://suno.ai",
    logo: "https://favicon.show/suno.ai",
    rating: 4.7,
    reviews: 32000,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-12-20",
    updatedDate: "2026-07-10",
    tags: ["music", "song generation", "vocals", "lyrics"],
    featured: true
  },
  {
    id: "udio",
    name: "Udio",
    tagline: "Discover, create, and listen to AI music",
    description: "Udio is an AI music generation platform that creates high-quality songs across genres. From text prompts to radio-ready tracks.",
    category: "music",
    url: "https://udio.com",
    logo: "https://favicon.show/udio.com",
    rating: 4.7,
    reviews: 18500,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-04-10",
    updatedDate: "2026-07-09",
    tags: ["music", "generation", "genres", "audio"]
  },
  {
    id: "aiva",
    name: "AIVA",
    tagline: "AI music composer for emotional soundtracks",
    description: "AIVA composes emotional music in 250+ styles. Perfect for games, films, ads, and content. Full copyright ownership on paid plans.",
    category: "music",
    url: "https://aiva.ai",
    logo: "https://favicon.show/aiva.ai",
    rating: 4.4,
    reviews: 5200,
    pricing: "freemium",
    priceDetail: "Free tier, then $11/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-02-15",
    updatedDate: "2026-03-10",
    tags: ["music", "soundtrack", "composition", "games"]
  },
  {
    id: "soundraw",
    name: "Soundraw",
    tagline: "Custom AI music for creators",
    description: "Soundraw is an AI music generator that creates royalty-free songs tailored to your content. Customize length, structure, and mood.",
    category: "music",
    url: "https://soundraw.io",
    logo: "https://favicon.show/soundraw.io",
    rating: 4.5,
    reviews: 4100,
    pricing: "freemium",
    priceDetail: "Free tier, then $13.99/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-05-22",
    updatedDate: "2026-04-05",
    tags: ["music", "royalty-free", "custom", "creators"]
  },
  {
    id: "boomy",
    name: "Boomy",
    tagline: "Make original songs in seconds",
    description: "Boomy lets anyone create original songs in seconds, even with no musical experience. Distribute to streaming platforms and earn royalties.",
    category: "music",
    url: "https://boomy.com",
    logo: "https://favicon.show/boomy.com",
    rating: 4.3,
    reviews: 3600,
    pricing: "freemium",
    priceDetail: "Free tier, then $9.99/mo",
    trending: false,
    topRated: false,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-04-18",
    updatedDate: "2026-02-20",
    tags: ["music", "distribution", "beginner", "royalties"]
  },
  {
    id: "elevenlabs-music",
    name: "ElevenLabs Music",
    tagline: "AI music from the voice leaders",
    description: "ElevenLabs Music brings studio-quality AI music generation to creators. Generate full songs with vocals from simple text prompts.",
    category: "music",
    url: "https://elevenlabs.io/music",
    logo: "https://favicon.show/elevenlabs.io",
    rating: 4.7,
    reviews: 1800,
    pricing: "paid",
    priceDetail: "From $5/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-05-22",
    updatedDate: "2026-07-10",
    tags: ["music", "ElevenLabs", "vocals", "studio"]
  },

  // ===== AI Coding (10) =====
  {
    id: "copilot",
    name: "GitHub Copilot",
    tagline: "Your AI pair programmer",
    description: "GitHub Copilot uses OpenAI Codex to suggest code and entire functions in real-time, right from your editor. Trained on billions of lines of code.",
    category: "coding",
    url: "https://github.com/features/copilot",
    logo: "https://favicon.show/github.com",
    rating: 4.7,
    reviews: 95000,
    pricing: "paid",
    priceDetail: "$10/mo, free for students",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2022-06-21",
    updatedDate: "2026-07-08",
    tags: ["coding", "pair programming", "completion", "GitHub"],
    featured: true
  },
  {
    id: "cursor",
    name: "Cursor",
    tagline: "The AI-first code editor",
    description: "Cursor is a code editor built on VSCode with deep AI integration. Chat, edit, and refactor your codebase with frontier models.",
    category: "coding",
    url: "https://cursor.sh",
    logo: "https://favicon.show/cursor.sh",
    rating: 4.8,
    reviews: 12000,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2024-08-15",
    updatedDate: "2026-07-10",
    tags: ["coding", "editor", "refactor", "agent"]
  },
  {
    id: "codeium",
    name: "Codeium",
    tagline: "Free AI code completion",
    description: "Codeium offers free AI-powered code completion, chat, and search across 70+ languages. Integrates with every major editor.",
    category: "coding",
    url: "https://codeium.com",
    logo: "https://favicon.show/codeium.com",
    rating: 4.6,
    reviews: 22000,
    pricing: "free",
    priceDetail: "Free for individuals",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-08-20",
    updatedDate: "2026-06-18",
    tags: ["coding", "completion", "free", "IDE"]
  },
  {
    id: "tabnine",
    name: "Tabnine",
    tagline: "Personalized AI coding assistant",
    description: "Tabnine is an AI coding assistant that suggests code completions based on context and your coding patterns. Privacy-focused, can run on-prem.",
    category: "coding",
    url: "https://tabnine.com",
    logo: "https://favicon.show/tabnine.com",
    rating: 4.5,
    reviews: 8500,
    pricing: "freemium",
    priceDetail: "Free tier, then $12/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-03-10",
    updatedDate: "2026-04-20",
    tags: ["coding", "privacy", "enterprise", "completion"]
  },
  {
    id: "replit",
    name: "Replit",
    tagline: "Code, create, and learn with AI",
    description: "Replit is a browser-based IDE with built-in AI. Build, deploy, and host apps from your browser with the Ghostwriter AI pair programmer.",
    category: "coding",
    url: "https://replit.com",
    logo: "https://favicon.show/replit.com",
    rating: 4.6,
    reviews: 19000,
    pricing: "freemium",
    priceDetail: "Free tier available",
    trending: true,
    topRated: false,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-07-15",
    updatedDate: "2026-06-25",
    tags: ["coding", "IDE", "cloud", "deploy"]
  },
  {
    id: "v0",
    name: "v0 by Vercel",
    tagline: "AI UI generator for React",
    description: "v0 generates React components with Tailwind CSS and shadcn/ui from text prompts. Perfect for rapid prototyping and design-to-code.",
    category: "coding",
    url: "https://v0.dev",
    logo: "https://favicon.show/v0.dev",
    rating: 4.8,
    reviews: 7800,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-01-10",
    updatedDate: "2026-07-09",
    tags: ["coding", "UI", "React", "Tailwind"]
  },
  {
    id: "claude-code",
    name: "Claude Code",
    tagline: "Anthropic's agentic coding CLI",
    description: "Claude Code is Anthropic's agentic coding tool. Reads, edits, and runs code in your terminal. Understands full codebases.",
    category: "coding",
    url: "https://claude.ai/claude-code",
    logo: "https://favicon.show/anthropic.com",
    rating: 4.9,
    reviews: 5200,
    pricing: "freemium",
    priceDetail: "Free tier, then usage-based",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-05",
    updatedDate: "2026-07-10",
    tags: ["coding", "agentic", "CLI", "Anthropic"]
  },
  {
    id: "windsurf",
    name: "Windsurf",
    tagline: "AI-powered IDE by Codeium",
    description: "Windsurf is the AI-powered IDE by Codeium. Cascade agent keeps context across your project, with Flows for multi-step coding tasks.",
    category: "coding",
    url: "https://codeium.com/windsurf",
    logo: "https://favicon.show/codeium.com",
    rating: 4.7,
    reviews: 4100,
    pricing: "freemium",
    priceDetail: "Free tier, then $15/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2025-12-18",
    updatedDate: "2026-07-07",
    tags: ["coding", "IDE", "agent", "Codeium"]
  },
  {
    id: "bolt",
    name: "Bolt.new",
    tagline: "AI web app builder by StackBlitz",
    description: "Bolt.new lets you prompt, edit, and deploy full-stack web apps from your browser. Powered by WebContainers and Claude.",
    category: "coding",
    url: "https://bolt.new",
    logo: "https://favicon.show/bolt.new",
    rating: 4.7,
    reviews: 3600,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-02-28",
    updatedDate: "2026-07-09",
    tags: ["coding", "full-stack", "deploy", "browser"]
  },
  {
    id: "lovable",
    name: "Lovable",
    tagline: "AI app builder for non-developers",
    description: "Lovable (ex-GPT Engineer) builds production-ready web apps from text prompts. Includes auth, database, and one-click deploy.",
    category: "coding",
    url: "https://lovable.dev",
    logo: "https://favicon.show/lovable.dev",
    rating: 4.6,
    reviews: 2900,
    pricing: "freemium",
    priceDetail: "Free tier, then $25/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-03-15",
    updatedDate: "2026-07-08",
    tags: ["coding", "no-code", "deploy", "apps"]
  },

  // ===== AI Writing (5) =====
  {
    id: "jasper",
    name: "Jasper",
    tagline: "AI copilot for marketing teams",
    description: "Jasper is an AI platform built for marketing teams. Create brand-consistent content, campaigns, and copy at scale with brand voice and knowledge bases.",
    category: "writing",
    url: "https://jasper.ai",
    logo: "https://favicon.show/jasper.ai",
    rating: 4.5,
    reviews: 14000,
    pricing: "paid",
    priceDetail: "From $49/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-02-10",
    updatedDate: "2026-05-15",
    tags: ["writing", "marketing", "brand", "enterprise"]
  },
  {
    id: "copyai",
    name: "Copy.ai",
    tagline: "AI-powered marketing copy in seconds",
    description: "Copy.ai helps marketers, sales teams, and entrepreneurs create high-quality copy for emails, blogs, social, and ads. Workflow automation included.",
    category: "writing",
    url: "https://copy.ai",
    logo: "https://favicon.show/copy.ai",
    rating: 4.6,
    reviews: 11500,
    pricing: "freemium",
    priceDetail: "Free tier, then $36/mo",
    trending: true,
    topRated: false,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-04-05",
    updatedDate: "2026-05-30",
    tags: ["writing", "copywriting", "marketing", "automation"]
  },
  {
    id: "grammarly",
    name: "Grammarly",
    tagline: "AI writing assistance everywhere",
    description: "Grammarly uses AI to help you write clearly and effectively. Grammar, tone, clarity, and full-sentence rewrites across all your apps and the web.",
    category: "writing",
    url: "https://grammarly.com",
    logo: "https://favicon.show/grammarly.com",
    rating: 4.7,
    reviews: 88000,
    pricing: "freemium",
    priceDetail: "Free tier, then $12/mo",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2022-05-15",
    updatedDate: "2026-07-01",
    tags: ["writing", "grammar", "editing", "productivity"]
  },
  {
    id: "writesonic",
    name: "Writesonic",
    tagline: "AI writer for SEO & content",
    description: "Writesonic is an AI writer that creates SEO-optimized articles, blog posts, and ads. Includes fact-checked content and brand voice training.",
    category: "writing",
    url: "https://writesonic.com",
    logo: "https://favicon.show/writesonic.com",
    rating: 4.5,
    reviews: 9800,
    pricing: "freemium",
    priceDetail: "Free trial, then $20/mo",
    trending: false,
    topRated: false,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-06-22",
    updatedDate: "2026-04-10",
    tags: ["writing", "SEO", "blogging", "content"]
  },
  {
    id: "rytr",
    name: "Rytr",
    tagline: "AI writing assistant that gets you",
    description: "Rytr is an AI writing assistant that helps you create high-quality content in 30+ use cases and 30+ languages. Affordable and easy to use.",
    category: "writing",
    url: "https://rytr.me",
    logo: "https://favicon.show/rytr.me",
    rating: 4.5,
    reviews: 7200,
    pricing: "freemium",
    priceDetail: "Free tier, then $9/mo",
    trending: false,
    topRated: false,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-04-12",
    updatedDate: "2026-03-18",
    tags: ["writing", "affordable", "multilingual"]
  },

  // ===== AI Design (3) =====
  {
    id: "recraft",
    name: "Recraft",
    tagline: "AI design tool for brand visuals",
    description: "Recraft generates brand-consistent visuals, illustrations, icons, and mockups. The first AI design tool with vector output and a brand kit.",
    category: "design",
    url: "https://recraft.ai",
    logo: "https://favicon.show/recraft.ai",
    rating: 4.7,
    reviews: 3200,
    pricing: "freemium",
    priceDetail: "Free tier, then $12/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-03-08",
    updatedDate: "2026-07-06",
    tags: ["design", "vector", "branding", "logos"]
  },
  {
    id: "canva",
    name: "Magic Studio by Canva",
    tagline: "AI design inside the Canva ecosystem",
    description: "Canva's Magic Studio brings AI image generation, brand kits, and design automation to 200M+ Canva users. Magic Design, Magic Edit, and Magic Write.",
    category: "design",
    url: "https://canva.com/magic-studio",
    logo: "https://favicon.show/canva.com",
    rating: 4.7,
    reviews: 56000,
    pricing: "freemium",
    priceDetail: "Free tier, Pro $13/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-11-20",
    updatedDate: "2026-07-02",
    tags: ["design", "Canva", "templates", "graphics"]
  },
  {
    id: "galileo",
    name: "Galileo AI",
    tagline: "AI UI design from text prompts",
    description: "Galileo AI generates beautiful UI designs from simple text descriptions. Built for product designers who want to move fast.",
    category: "design",
    url: "https://usegalileo.ai",
    logo: "https://favicon.show/usegalileo.ai",
    rating: 4.6,
    reviews: 2100,
    pricing: "freemium",
    priceDetail: "Free tier, then $19/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-15",
    updatedDate: "2026-07-08",
    tags: ["design", "UI", "Figma", "prototyping"]
  },

  // ===== AI Productivity (4) =====
  {
    id: "mem",
    name: "Mem",
    tagline: "Self-organizing workspace with AI",
    description: "Mem is a notes and knowledge base app that uses AI to organize itself. Just capture ideas and Mem finds connections automatically.",
    category: "productivity",
    url: "https://mem.ai",
    logo: "https://favicon.show/mem.ai",
    rating: 4.5,
    reviews: 3200,
    pricing: "freemium",
    priceDetail: "Free tier, then $9.99/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-03-22",
    updatedDate: "2026-04-30",
    tags: ["productivity", "notes", "knowledge", "organization"]
  },
  {
    id: "reclaim",
    name: "Reclaim",
    tagline: "AI calendar for productivity",
    description: "Reclaim.ai is a smart calendar app that schedules your tasks, habits, meetings, and breaks automatically. Defends focus time.",
    category: "productivity",
    url: "https://reclaim.ai",
    logo: "https://favicon.show/reclaim.ai",
    rating: 4.7,
    reviews: 4400,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-04-18",
    updatedDate: "2026-07-03",
    tags: ["productivity", "calendar", "scheduling", "tasks"]
  },
  {
    id: "taskade",
    name: "Taskade",
    tagline: "AI-powered team workspace",
    description: "Taskade is an AI-powered workspace for teams. Build tasks, notes, and projects with AI agents that automate workflows.",
    category: "productivity",
    url: "https://taskade.com",
    logo: "https://favicon.show/taskade.com",
    rating: 4.6,
    reviews: 3900,
    pricing: "freemium",
    priceDetail: "Free tier, then $8/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-06-15",
    updatedDate: "2026-05-12",
    tags: ["productivity", "teams", "tasks", "agents"]
  },
  {
    id: "notion-ai",
    name: "Notion AI",
    tagline: "AI inside your workspace",
    description: "Notion AI brings AI-powered writing, summaries, translations, and Q&A directly into your Notion workspace. Native to docs, projects, and wikis.",
    category: "productivity",
    url: "https://notion.so/product/ai",
    logo: "https://favicon.show/notion.so",
    rating: 4.6,
    reviews: 18000,
    pricing: "paid",
    priceDetail: "$10/mo add-on",
    trending: false,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-11-15",
    updatedDate: "2026-06-22",
    tags: ["productivity", "workspace", "docs", "knowledge"]
  },

  // ===== AI Marketing (5) =====
  {
    id: "surfer",
    name: "Surfer SEO",
    tagline: "AI-powered content optimization",
    description: "Surfer SEO is a content intelligence platform that helps you research, write, and optimize SEO content that ranks on Google.",
    category: "marketing",
    url: "https://surferseo.com",
    logo: "https://favicon.show/surferseo.com",
    rating: 4.7,
    reviews: 9200,
    pricing: "paid",
    priceDetail: "From $89/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-08-15",
    updatedDate: "2026-07-02",
    tags: ["marketing", "SEO", "content", "optimization"]
  },
  {
    id: "marketmuse",
    name: "MarketMuse",
    tagline: "AI content planning and optimization",
    description: "MarketMuse uses AI to analyze content, identify gaps, and build content strategies that drive authority and traffic.",
    category: "marketing",
    url: "https://marketmuse.com",
    logo: "https://favicon.show/marketmuse.com",
    rating: 4.6,
    reviews: 3100,
    pricing: "paid",
    priceDetail: "From $149/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-05-12",
    updatedDate: "2026-04-22",
    tags: ["marketing", "content strategy", "SEO", "enterprise"]
  },
  {
    id: "smartwriter",
    name: "Smartwriter",
    tagline: "AI for personalized outreach",
    description: "Smartwriter generates hyper-personalized cold emails and outreach at scale. Backed by AI research of each prospect's online presence.",
    category: "marketing",
    url: "https://smartwriter.ai",
    logo: "https://favicon.show/smartwriter.ai",
    rating: 4.5,
    reviews: 2800,
    pricing: "paid",
    priceDetail: "From $59/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-07-08",
    updatedDate: "2026-03-15",
    tags: ["marketing", "cold email", "personalization", "outreach"]
  },
  {
    id: "adcreative",
    name: "AdCreative.ai",
    tagline: "AI ad creatives that convert",
    description: "AdCreative.ai generates conversion-focused ad creatives, banners, and social media posts in seconds. Predictive scoring for best performers.",
    category: "marketing",
    url: "https://adcreative.ai",
    logo: "https://favicon.show/adcreative.ai",
    rating: 4.6,
    reviews: 5800,
    pricing: "paid",
    priceDetail: "From $29/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-09-25",
    updatedDate: "2026-06-28",
    tags: ["marketing", "ads", "banners", "conversion"]
  },
  {
    id: "lately",
    name: "Lately",
    tagline: "AI social media content engine",
    description: "Lately turns long-form content into dozens of high-performing social posts using AI. Used by major brands to scale social media output.",
    category: "marketing",
    url: "https://lately.ai",
    logo: "https://favicon.show/lately.ai",
    rating: 4.5,
    reviews: 2200,
    pricing: "paid",
    priceDetail: "From $99/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-06-30",
    updatedDate: "2026-06-15",
    tags: ["marketing", "social media", "content", "enterprise"]
  },

  // ===== AI Education (6) =====
  {
    id: "khanmigo",
    name: "Khanmigo",
    tagline: "AI tutor from Khan Academy",
    description: "Khanmigo is Khan Academy's AI-powered tutor. Helps students with homework, writing, and learning, and helps teachers with lessons.",
    category: "education",
    url: "https://khanacademy.org/khan-labs",
    logo: "https://favicon.show/khanacademy.org",
    rating: 4.6,
    reviews: 4100,
    pricing: "freemium",
    priceDetail: "Free with limitations",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-05-18",
    updatedDate: "2026-07-04",
    tags: ["education", "tutor", "K-12", "homework"]
  },
  {
    id: "duolingo",
    name: "Duolingo Max",
    tagline: "AI language learning with GPT-4",
    description: "Duolingo Max adds AI-powered features like Roleplay and Explain My Answer, powered by GPT-4, to the world's most popular language app.",
    category: "education",
    url: "https://duolingo.com",
    logo: "https://favicon.show/duolingo.com",
    rating: 4.7,
    reviews: 320000,
    pricing: "freemium",
    priceDetail: "Free, $13.99/mo Super",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-03-15",
    updatedDate: "2026-07-02",
    tags: ["education", "language", "learning", "mobile"]
  },
  {
    id: "quizlet",
    name: "Quizlet",
    tagline: "AI-powered study tools",
    description: "Quizlet uses AI to create flashcards, practice tests, and study guides. Q-Chat is an AI tutor that adapts to your learning.",
    category: "education",
    url: "https://quizlet.com",
    logo: "https://favicon.show/quizlet.com",
    rating: 4.5,
    reviews: 180000,
    pricing: "freemium",
    priceDetail: "Free, $7.99/mo Plus",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-02-08",
    updatedDate: "2026-06-20",
    tags: ["education", "flashcards", "study", "students"]
  },
  {
    id: "socratic",
    name: "Socratic",
    tagline: "AI homework help by Google",
    description: "Socratic by Google uses AI to help students understand schoolwork. Snap a photo and get explanations, videos, and step-by-step help.",
    category: "education",
    url: "https://socratic.org",
    logo: "https://favicon.show/socratic.org",
    rating: 4.6,
    reviews: 22000,
    pricing: "free",
    priceDetail: "Free",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-01-25",
    updatedDate: "2026-03-22",
    tags: ["education", "homework", "mobile", "Google"]
  },
  {
    id: "photomath",
    name: "Photomath",
    tagline: "AI math problem solver",
    description: "Photomath scans and solves math problems with step-by-step explanations. From arithmetic to calculus, powered by AI.",
    category: "education",
    url: "https://photomath.com",
    logo: "https://favicon.show/photomath.com",
    rating: 4.7,
    reviews: 85000,
    pricing: "freemium",
    priceDetail: "Free, $9.99/mo Plus",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-04-30",
    updatedDate: "2026-06-25",
    tags: ["education", "math", "homework", "mobile"]
  },
  {
    id: "curipod",
    name: "Curipod",
    tagline: "AI lessons for teachers",
    description: "Curipod helps teachers create interactive AI lessons in seconds. Live polls, drawings, and open-ended questions for the classroom.",
    category: "education",
    url: "https://curipod.com",
    logo: "https://favicon.show/curipod.com",
    rating: 4.7,
    reviews: 1200,
    pricing: "freemium",
    priceDetail: "Free tier available",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-03-22",
    updatedDate: "2026-07-09",
    tags: ["education", "teachers", "lessons", "classroom"]
  },

  // ===== AI Research (5) =====
  {
    id: "perplexity",
    name: "Perplexity",
    tagline: "AI answer engine with sources",
    description: "Perplexity is an AI search engine that gives you accurate, sourced answers to any question. Cites real-time web sources.",
    category: "research",
    url: "https://perplexity.ai",
    logo: "https://favicon.show/perplexity.ai",
    rating: 4.7,
    reviews: 28000,
    pricing: "freemium",
    priceDetail: "Free, $20/mo Pro",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-08-10",
    updatedDate: "2026-07-08",
    tags: ["research", "search", "answers", "citations"]
  },
  {
    id: "perplexity-pro",
    name: "Perplexity Pro",
    tagline: "Pro AI search with frontier models",
    description: "Perplexity Pro is the pro version of the AI answer engine. Choose between GPT-4o, Claude, and Sonar models. Cites real-time web sources.",
    category: "research",
    url: "https://perplexity.ai",
    logo: "https://favicon.show/perplexity.ai",
    rating: 4.8,
    reviews: 18000,
    pricing: "freemium",
    priceDetail: "Free, $20/mo Pro",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-01-20",
    updatedDate: "2026-07-09",
    tags: ["research", "pro", "frontier models", "citations"]
  },
  {
    id: "elicit",
    name: "Elicit",
    tagline: "AI research assistant for academics",
    description: "Elicit uses AI to find, read, and synthesize research papers. Trusted by 2M+ researchers to find relevant studies and extract data.",
    category: "research",
    url: "https://elicit.com",
    logo: "https://favicon.show/elicit.com",
    rating: 4.7,
    reviews: 3800,
    pricing: "freemium",
    priceDetail: "Free tier, then $10/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-09-15",
    updatedDate: "2026-07-05",
    tags: ["research", "academic", "papers", "synthesis"]
  },
  {
    id: "consensus",
    name: "Consensus",
    tagline: "AI search engine for research",
    description: "Consensus is an AI search engine that pulls answers directly from peer-reviewed scientific studies. Find what the research actually says.",
    category: "research",
    url: "https://consensus.app",
    logo: "https://favicon.show/consensus.app",
    rating: 4.7,
    reviews: 2400,
    pricing: "freemium",
    priceDetail: "Free tier, then $9/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-11-12",
    updatedDate: "2026-06-30",
    tags: ["research", "science", "peer-reviewed", "search"]
  },
  {
    id: "scite",
    name: "Scite",
    tagline: "AI citation analysis for research",
    description: "Scite uses AI to analyze how scientific papers cite each other. Tells you whether citations support or contrast the cited claim.",
    category: "research",
    url: "https://scite.ai",
    logo: "https://favicon.show/scite.ai",
    rating: 4.6,
    reviews: 1800,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: false,
    topRated: true,
    popular: false,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-12-01",
    updatedDate: "2026-06-10",
    tags: ["research", "citations", "academic", "analysis"]
  },

  // ===== AI Business (5) =====
  {
    id: "persado",
    name: "Persado",
    tagline: "Enterprise AI for language",
    description: "Persado's enterprise AI generates language that performs across email, web, SMS, and push. Drives engagement and conversions for Fortune 500 brands.",
    category: "business",
    url: "https://persado.com",
    logo: "https://favicon.show/persado.com",
    rating: 4.5,
    reviews: 1900,
    pricing: "paid",
    priceDetail: "Enterprise pricing",
    trending: false,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-04-10",
    updatedDate: "2026-02-12",
    tags: ["business", "enterprise", "language", "engagement"]
  },
  {
    id: "motion",
    name: "Motion",
    tagline: "AI project and task manager",
    description: "Motion uses AI to build your daily schedule. Combines tasks, projects, and calendar into one auto-prioritized agenda for busy teams.",
    category: "business",
    url: "https://usemotion.com",
    logo: "https://favicon.show/usemotion.com",
    rating: 4.6,
    reviews: 5800,
    pricing: "paid",
    priceDetail: "From $19/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-05-08",
    updatedDate: "2026-06-25",
    tags: ["business", "projects", "tasks", "calendar"]
  },
  {
    id: "fyxer",
    name: "Fyxer AI",
    tagline: "AI executive assistant for email",
    description: "Fyxer is an AI executive assistant that drafts email replies, organizes your inbox, and takes meeting notes. Saves 1+ hour per day.",
    category: "business",
    url: "https://fyxer.com",
    logo: "https://favicon.show/fyxer.com",
    rating: 4.6,
    reviews: 1800,
    pricing: "freemium",
    priceDetail: "Free trial, then $14.50/mo",
    trending: true,
    topRated: false,
    popular: false,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-08",
    updatedDate: "2026-07-09",
    tags: ["business", "email", "executive", "inbox"]
  },
  {
    id: "clay",
    name: "Clay",
    tagline: "AI-powered data enrichment and outreach",
    description: "Clay combines 50+ data sources with AI to enrich leads and write personalized outreach. The go-to tool for modern B2B sales teams.",
    category: "business",
    url: "https://clay.com",
    logo: "https://favicon.show/clay.com",
    rating: 4.7,
    reviews: 2900,
    pricing: "freemium",
    priceDetail: "Free trial, then $149/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-05-01",
    updatedDate: "2026-07-08",
    tags: ["business", "B2B", "sales", "outreach", "data"]
  },
  {
    id: "raycast",
    name: "Raycast AI",
    tagline: "AI inside your launcher",
    description: "Raycast AI brings AI into the macOS launcher. Quick chat, snippets, and commands powered by GPT and Claude. Lightning fast for power users.",
    category: "business",
    url: "https://raycast.com",
    logo: "https://favicon.show/raycast.com",
    rating: 4.8,
    reviews: 6800,
    pricing: "freemium",
    priceDetail: "Free tier, then $8/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-10-22",
    updatedDate: "2026-07-01",
    tags: ["business", "launcher", "macOS", "productivity"]
  },

  // ===== AI 3D (4) =====
  {
    id: "meshy",
    name: "Meshy",
    tagline: "AI 3D model generation from text or image",
    description: "Meshy turns text and images into production-ready 3D models in seconds. Includes auto-rigging and texturing. Used by 3M+ creators.",
    category: "3d",
    url: "https://meshy.ai",
    logo: "https://favicon.show/meshy.ai",
    rating: 4.7,
    reviews: 3200,
    pricing: "freemium",
    priceDetail: "Free tier, then $20/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-20",
    updatedDate: "2026-07-10",
    tags: ["3d", "text-to-3d", "image-to-3d", "rigging"]
  },
  {
    id: "tripo3d",
    name: "Tripo3D",
    tagline: "AI 3D model from a single image",
    description: "Tripo3D generates high-quality 3D models from a single image in seconds. Free, fast, and surprisingly detailed.",
    category: "3d",
    url: "https://tripo3d.ai",
    logo: "https://favicon.show/tripo3d.ai",
    rating: 4.6,
    reviews: 2400,
    pricing: "freemium",
    priceDetail: "Free tier, then $9.99/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-03-25",
    updatedDate: "2026-07-09",
    tags: ["3d", "image-to-3d", "modeling"]
  },
  {
    id: "luma",
    name: "Luma AI",
    tagline: "3D capture and video from video",
    description: "Luma AI turns phone videos into photorealistic 3D scenes with Genie. Also offers Dream Machine for AI video generation.",
    category: "3d",
    url: "https://lumalabs.ai",
    logo: "https://favicon.show/lumalabs.ai",
    rating: 4.7,
    reviews: 5100,
    pricing: "freemium",
    priceDetail: "Free tier, then $24/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-12-15",
    updatedDate: "2026-07-06",
    tags: ["3d", "capture", "video", "photorealistic"]
  },
  {
    id: "sloyd",
    name: "Sloyd",
    tagline: "AI 3D modeling for game devs",
    description: "Sloyd generates ready-to-use 3D models from text descriptions. Optimized for game development with automatic LODs and UVs.",
    category: "3d",
    url: "https://sloyd.ai",
    logo: "https://favicon.show/sloyd.ai",
    rating: 4.6,
    reviews: 1600,
    pricing: "freemium",
    priceDetail: "Free tier, then $15/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: true,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-04-12",
    updatedDate: "2026-07-08",
    tags: ["3d", "games", "modeling", "text-to-3d"]
  },

  // ===== AI Avatar (5) =====
  {
    id: "synthesia",
    name: "Synthesia",
    tagline: "AI video generation with 230+ avatars",
    description: "Create professional videos with AI avatars in 140+ languages. Perfect for training, marketing, and corporate communications without cameras or studios.",
    category: "avatar",
    url: "https://synthesia.io",
    logo: "https://favicon.show/synthesia.io",
    rating: 4.6,
    reviews: 9200,
    pricing: "paid",
    priceDetail: "From $22/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-09-15",
    updatedDate: "2026-06-28",
    tags: ["avatar", "video", "corporate", "multilingual"]
  },
  {
    id: "heygen",
    name: "HeyGen",
    tagline: "AI avatar videos at scale",
    description: "Generate studio-quality videos with AI avatars and voices. Translate content into 40+ languages with one click. Ideal for marketing, sales, and learning.",
    category: "avatar",
    url: "https://heygen.com",
    logo: "https://favicon.show/heygen.com",
    rating: 4.7,
    reviews: 6700,
    pricing: "freemium",
    priceDetail: "Free trial, then $24/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: false,
    addedDate: "2023-12-08",
    updatedDate: "2026-06-12",
    tags: ["avatar", "video", "translation", "marketing"]
  },
  {
    id: "did",
    name: "D-ID",
    tagline: "Talking avatars from a single photo",
    description: "D-ID turns any photo into a talking avatar video. Used by 200M+ users to create personalized video at scale via API or studio.",
    category: "avatar",
    url: "https://d-id.com",
    logo: "https://favicon.show/d-id.com",
    rating: 4.6,
    reviews: 4800,
    pricing: "freemium",
    priceDetail: "Free trial, then $5.99/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-08-22",
    updatedDate: "2026-07-02",
    tags: ["avatar", "talking", "photo", "video"]
  },
  {
    id: "tavus",
    name: "Tavus",
    tagline: "AI video personalization at scale",
    description: "Tavus lets you record once and generate thousands of personalized videos for every recipient. AI clones your face and voice.",
    category: "avatar",
    url: "https://tavus.io",
    logo: "https://favicon.show/tavus.io",
    rating: 4.7,
    reviews: 2100,
    pricing: "paid",
    priceDetail: "From $225/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-05-05",
    updatedDate: "2026-07-09",
    tags: ["avatar", "personalization", "sales", "video"]
  },
  {
    id: "argil",
    name: "Argil",
    tagline: "AI avatar videos in 5 minutes",
    description: "Argil creates short-form avatar videos from your scripts. Built for creators, marketers, and educators. No filming required.",
    category: "avatar",
    url: "https://argil.ai",
    logo: "https://favicon.show/argil.ai",
    rating: 4.6,
    reviews: 1400,
    pricing: "freemium",
    priceDetail: "Free trial, then $39/mo",
    trending: true,
    topRated: true,
    popular: false,
    free: false,
    isNew: true,
    recentlyUpdated: true,
    addedDate: "2026-05-18",
    updatedDate: "2026-07-08",
    tags: ["avatar", "short-form", "social", "creators"]
  },

  // ===== Other (2) =====
  {
    id: "make",
    name: "Make",
    tagline: "Visual platform to design, build, automate",
    description: "Make (formerly Integromat) is a no-code automation platform that connects apps and services. AI-powered workflows from spreadsheets to CRMs.",
    category: "other",
    url: "https://make.com",
    logo: "https://favicon.show/make.com",
    rating: 4.7,
    reviews: 5200,
    pricing: "freemium",
    priceDetail: "Free tier, then $9/mo",
    trending: false,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-07-10",
    updatedDate: "2026-06-25",
    tags: ["other", "automation", "no-code", "workflow"]
  },
  {
    id: "huggingface",
    name: "Hugging Face",
    tagline: "The AI community and model hub",
    description: "Hugging Face is the GitHub of AI: 1M+ models, datasets, and apps. Build, train, and deploy ML with open-source tools.",
    category: "other",
    url: "https://huggingface.co",
    logo: "https://favicon.show/huggingface.co",
    rating: 4.8,
    reviews: 18000,
    pricing: "freemium",
    priceDetail: "Free tier, then $9/mo",
    trending: true,
    topRated: true,
    popular: true,
    free: true,
    isNew: false,
    recentlyUpdated: true,
    addedDate: "2023-05-08",
    updatedDate: "2026-07-08",
    tags: ["other", "models", "open source", "ML"]
  },
];

// Count tools per category
TOOLS.forEach(tool => {
  const cat = CATEGORIES.find(c => c.id === tool.category);
  if (cat) cat.count++;
});

// Compute featured stats
const STATS = {
  totalTools: TOOLS.length,
  totalCategories: CATEGORIES.length,
  freeTools: TOOLS.filter(t => t.free).length,
  trendingTools: TOOLS.filter(t => t.trending).length,
  newTools: TOOLS.filter(t => t.isNew).length,
  popularTools: TOOLS.filter(t => t.popular).length,
  updatedTools: TOOLS.filter(t => t.recentlyUpdated).length,
};

// Get tool by id
function getToolById(id) {
  return TOOLS.find(t => t.id === id);
}

// Get tools by category
function getToolsByCategory(categoryId) {
  return TOOLS.filter(t => t.category === categoryId);
}

// Get trending tools
function getTrendingTools(limit = 8) {
  return TOOLS.filter(t => t.trending).slice(0, limit);
}

// Get top rated tools
function getTopRatedTools(limit = 8) {
  return [...TOOLS].sort((a, b) => b.rating - a.rating).slice(0, limit);
}

// Get free tools
function getFreeTools(limit = 8) {
  return TOOLS.filter(t => t.free).slice(0, limit);
}

// Get newest tools
function getNewestTools(limit = 8) {
  return [...TOOLS]
    .filter(t => t.isNew)
    .sort((a, b) => new Date(b.addedDate) - new Date(a.addedDate))
    .slice(0, limit);
}

// Get most popular this week
function getPopularThisWeekTools(limit = 8) {
  return [...TOOLS]
    .filter(t => t.popular)
    .sort((a, b) => b.reviews - a.reviews)
    .slice(0, limit);
}

// Get recently updated tools
function getRecentlyUpdatedTools(limit = 8) {
  return [...TOOLS]
    .filter(t => t.recentlyUpdated)
    .sort((a, b) => new Date(b.updatedDate) - new Date(a.updatedDate))
    .slice(0, limit);
}

// Get featured tools
function getFeaturedTools(limit = 4) {
  const featured = TOOLS.filter(t => t.featured);
  if (featured.length < limit) {
    const rest = getTopRatedTools(limit + 2).filter(t => !featured.find(f => f.id === t.id));
    return [...featured, ...rest].slice(0, limit);
  }
  return featured.slice(0, limit);
}

// ============================================
// SEMANTIC SEARCH (Bilingual EN + AR with Synonym Expansion)
// ============================================

// Normalize a string for searching:
// - lowercase
// - strip Arabic diacritics (tashkeel)
// - normalize alef variants (أ إ آ -> ا)
// - normalize taa marbuta (ة -> ه)
// - normalize yaa (ى -> ي)
// - remove tatweel
// - collapse whitespace
function normalizeText(s) {
  if (!s) return "";
  return String(s)
    .toLowerCase()
    .replace(/[\u064B-\u0652\u0670\u0640]/g, "")  // Arabic diacritics + tatweel
    .replace(/[\u0622\u0623\u0625\u0671]/g, "\u0627")  // alef variants -> ا
    .replace(/\u0629/g, "\u0647")  // taa marbuta -> ه
    .replace(/\u0649/g, "\u064a")  // alef maqsura -> ي
    .replace(/[^\w\s\u0600-\u06FF]/g, " ")  // remove punctuation
    .replace(/\s+/g, " ")
    .trim();
}

// Tokenize a query into normalized tokens
function tokenize(s) {
  const n = normalizeText(s);
  if (!n) return [];
  return n.split(" ").filter(t => t.length >= 1);
}

// Expand a single token to all related terms in both languages
function expandToken(token) {
  const expanded = new Set([token]);

  // Direct lookup
  if (SYNONYMS[token]) {
    SYNONYMS[token].forEach(s => expanded.add(normalizeText(s)));
  }

  // Reverse lookup — find entries that include this token
  for (const [key, syns] of Object.entries(SYNONYMS)) {
    const nk = normalizeText(key);
    if (nk === token || syns.some(s => normalizeText(s) === token)) {
      expanded.add(nk);
      syns.forEach(s => expanded.add(normalizeText(s)));
    }
  }

  return [...expanded];
}

// Expand all tokens, returning the union
function expandTokens(tokens) {
  const all = new Set();
  tokens.forEach(t => {
    expandToken(t).forEach(e => all.add(e));
  });
  return [...all];
}

// Find categories whose bilingual anchors match the query.
// Uses tiered phrase-based scoring: exact anchor matches dominate substring matches.
function matchCategories(query, tokens, expanded) {
  const matched = new Set();
  const normQ = normalizeText(query);

  for (const [catId, anchors] of Object.entries(CATEGORY_ANCHORS)) {
    let score = 0;
    for (const anchor of anchors) {
      const na = normalizeText(anchor);

      // Tier 1: Full normalized query IS an anchor (perfect direct match) — strongest
      if (na === normQ && normQ.length >= 2) {
        score += 300;
      }
      // Tier 2: Anchor contains full query (anchor is the more specific phrase)
      else if (normQ.length >= 3 && na.includes(normQ)) {
        score += 80 + normQ.length;
      }
      // Tier 3: Query contains anchor (user added extra context)
      else if (na.length >= 3 && normQ.includes(na)) {
        score += 50 + na.length * 2;
      }
      // Tier 4: Single-token query vs anchor (substring match)
      else if (tokens.length === 1 && tokens[0].length >= 3) {
        if (na === tokens[0]) {
          score += 100;
        } else if (na.includes(tokens[0]) || tokens[0].includes(na)) {
          score += 10;
        }
      }
    }
    if (score > 0) {
      matched.add(catId);
    }
  }

  return matched;
}

// Main search function with semantic understanding
function searchTools(query) {
  if (!query || !String(query).trim()) return TOOLS;

  const tokens = tokenize(query);
  if (tokens.length === 0) return TOOLS;

  const expanded = expandTokens(tokens);
  const expandedText = expanded.join(" ");

  // Find matched categories from bilingual anchors (phrase-based)
  const matchedCategoryIds = matchCategories(query, tokens, expanded);

  // Build results
  const results = new Map();

  // 1) Category-level match (high score, signals strong relevance)
  // Compute per-category scores using the same tiered logic as matchCategories
  const categoryScores = {};
  const normQ = normalizeText(query);
  matchedCategoryIds.forEach(catId => {
    let catScore = 60;
    const anchors = CATEGORY_ANCHORS[catId] || [];
    for (const a of anchors) {
      const na = normalizeText(a);
      if (na === normQ && normQ.length >= 2) {
        catScore += 300;
      } else if (normQ.length >= 3 && na.includes(normQ)) {
        catScore += 80 + normQ.length;
      } else if (na.length >= 3 && normQ.includes(na)) {
        catScore += 50 + na.length * 2;
      }
    }
    categoryScores[catId] = catScore;
  });
  TOOLS.forEach(t => {
    if (matchedCategoryIds.has(t.category)) {
      results.set(t.id, { tool: t, score: categoryScores[t.category] || 60 });
    }
  });

  // 2) Tool name and alias match (very high score — user likely wants this tool)
  TOOLS.forEach(t => {
    const nameNorm = normalizeText(t.name);
    let nameScore = 0;

    // Direct name match
    for (const tk of tokens) {
      if (nameNorm.includes(tk)) nameScore += 40;
      if (tk.length >= 3 && tk.includes(nameNorm)) nameScore += 35;
    }

    // Alias match
    const aliases = TOOL_ALIASES[t.id] || [];
    for (const alias of aliases) {
      const aNorm = normalizeText(alias);
      for (const tk of tokens) {
        if (aNorm.includes(tk) || tk.includes(aNorm)) nameScore += 45;
      }
    }

    if (nameScore > 0) {
      const existing = results.get(t.id);
      if (!existing || existing.score < nameScore + (existing.score - 50 || 0)) {
        results.set(t.id, { tool: t, score: 50 + nameScore });
      }
    }
  });

  // 3) Tagline match (high score — direct user-facing description)
  TOOLS.forEach(t => {
    const taglineNorm = normalizeText(t.tagline);
    let score = 0;
    for (const tk of tokens) {
      if (taglineNorm.includes(tk)) score += 18;
    }
    // Also check expanded tokens
    for (const e of expanded) {
      if (e.length < 2) continue;
      if (taglineNorm.includes(e) && !tokens.includes(e)) score += 5;
    }
    if (score > 0) {
      const existing = results.get(t.id);
      const catBonus = matchedCategoryIds.has(t.category) ? 20 : 0;
      const newScore = 25 + score + catBonus;
      if (!existing || existing.score < newScore) {
        results.set(t.id, { tool: t, score: newScore });
      }
    }
  });

  // 4) Description match
  TOOLS.forEach(t => {
    const descNorm = normalizeText(t.description);
    let score = 0;
    for (const tk of tokens) {
      if (descNorm.includes(tk)) score += 8;
    }
    for (const e of expanded) {
      if (e.length < 2) continue;
      if (descNorm.includes(e) && !tokens.includes(e)) score += 2;
    }
    if (score > 0) {
      const existing = results.get(t.id);
      const catBonus = matchedCategoryIds.has(t.category) ? 5 : 0;
      const newScore = 10 + score + catBonus;
      if (!existing || existing.score < newScore) {
        results.set(t.id, { tool: t, score: newScore });
      }
    }
  });

  // 5) Tag match
  TOOLS.forEach(t => {
    for (const tag of t.tags) {
      const tagNorm = normalizeText(tag);
      let score = 0;
      for (const tk of tokens) {
        if (tagNorm.includes(tk)) score += 12;
      }
      for (const e of expanded) {
        if (e.length < 2) continue;
        if (tagNorm.includes(e) && !tokens.includes(e)) score += 4;
      }
      if (score > 0) {
        const existing = results.get(t.id);
        const newScore = 15 + score;
        if (!existing || existing.score < newScore) {
          results.set(t.id, { tool: t, score: newScore });
        }
      }
    }
  });

  // 6) Category field match
  TOOLS.forEach(t => {
    const catObj = CATEGORIES.find(c => c.id === t.category);
    if (!catObj) return;
    const catNorm = normalizeText(catObj.name);
    const catArNorm = normalizeText(catObj.nameAr);
    let score = 0;
    for (const tk of tokens) {
      if (catNorm.includes(tk)) score += 25;
      if (catArNorm.includes(tk)) score += 25;
    }
    if (score > 0) {
      const existing = results.get(t.id);
      const newScore = 20 + score;
      if (!existing || existing.score < newScore) {
        results.set(t.id, { tool: t, score: newScore });
      }
    }
  });

  // Sort by score desc, then rating desc
  return [...results.values()]
    .sort((a, b) => b.score - a.score || b.tool.rating - a.tool.rating)
    .map(r => r.tool);
}
